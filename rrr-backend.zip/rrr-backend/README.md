# Rights Regression Radar - Backend (no ML)

Pure Python backend. No ML, no frontend. ML adapter is a stub that routes
everything to human review - swap it in `app/ml_adapter.py` when your model
is ready.

## Run
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env      # edit SECRET_KEY
    ./run.sh

OpenAPI: http://localhost:8000/docs

## First-run bootstrap
1. POST /api/auth/register - first user becomes admin.
2. POST /api/auth/token (form: username=email, password) -> JWT.
3. Use `Authorization: Bearer <token>` on all other calls.

## Plugging in the ML model
`app/ml_adapter.py` defines:
- MLAdapter.classify(bill_clause, evidence) -> Classification
- MLAdapter.tag_fundamental_rights(bill_clause) -> list[str]

Subclass, then at module bottom set:
    ML_ADAPTER = YourAdapter()

Everything else (job runner, endpoints, DB) stays untouched.

## Plugging in a real vector store
`app/retrieval.py` defines `RetrievalAdapter` and a default SQL exact-text
placeholder. Subclass it and swap `_default` at the bottom of the file.

## What's deliberately NOT here
- No ML training, no embeddings, no prompts.
- No Alembic migrations - `create_all()` on startup (swap later).
- No automated tests (you asked for backend only; add as needed).
- No PDF/DOCX parsing - uploads are UTF-8 `.txt`/`.md` only.
