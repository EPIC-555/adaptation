from sqlalchemy.orm import Session
from app.models import AuditLog


def log(
    db: Session,
    *,
    entity_type: str,
    entity_id: str,
    actor_id: str | None,
    action: str,
    previous: dict | None = None,
    new: dict | None = None,
    note: str | None = None,
) -> None:
    db.add(
        AuditLog(
            entity_type=entity_type,
            entity_id=entity_id,
            actor_id=actor_id,
            action=action,
            previous_value=previous,
            new_value=new,
            note=note,
        )
    )
