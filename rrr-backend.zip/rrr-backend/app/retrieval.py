"""
Retrieval adapter. The interface is stable; the default implementation
is an exact/ILIKE text search so this backend has zero ML dependencies.

Plug in a real vector DB implementation later by subclassing RetrievalAdapter
and swapping the instance via `get_retrieval()`.
"""
from dataclasses import dataclass
from typing import Protocol
from sqlalchemy import select, or_
from sqlalchemy.orm import Session
from app.models import Clause


@dataclass
class Retrieved:
    clause: Clause
    score: float


class RetrievalAdapter(Protocol):
    def retrieve(self, db: Session, query: str, k: int = 5) -> list[Retrieved]:
        ...


class SqlExactRetrieval:
    """
    Uses a LIKE match against clause text. Returns at most k results.
    Scoring = 1.0 if exact substring, 0.5 if only a token overlaps.
    This is a placeholder - it is deterministic, not ML, and exists so
    retrieval can be swapped later without changing the API.
    """

    def retrieve(self, db: Session, query: str, k: int = 5) -> list[Retrieved]:
        q = (query or "").strip()
        if not q:
            return []
        tokens = [t for t in q.split() if len(t) > 4][:8]
        if not tokens:
            tokens = [q]

        stmt = select(Clause).where(
            or_(*[Clause.text.ilike(f"%{t}%") for t in tokens])
        ).limit(k * 3)

        results = []
        lower_q = q.lower()
        for c in db.execute(stmt).scalars():
            if lower_q in c.text.lower():
                score = 1.0
            else:
                score = 0.5
            results.append(Retrieved(clause=c, score=score))

        results.sort(key=lambda r: r.score, reverse=True)
        return results[:k]


_default = SqlExactRetrieval()


def get_retrieval() -> RetrievalAdapter:
    return _default
