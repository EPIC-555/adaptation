from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_env: str = "development"
    secret_key: str = "change-me"
    access_token_expire_minutes: int = 120
    database_url: str = "sqlite:///./rrr.db"
    upload_dir: str = "./uploads"
    max_upload_bytes: int = 10 * 1024 * 1024
    job_poll_seconds: int = 2


settings = Settings()
