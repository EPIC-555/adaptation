"""
Deterministic clause splitter. No ML, no embeddings.
Splits on common Indian legislative headings:
  - "Section 1." / "1." / "1)" / "(1)"
  - "Article 14."
  - Chapter/Part markers are kept as headings, not clauses.
This is intentionally conservative: if it cannot find section numbers,
it falls back to paragraph blocks (blank-line separated).
"""
import re
from dataclasses import dataclass


@dataclass
class SplitClause:
    section_number: str | None
    heading: str | None
    text: str


_SECTION_RE = re.compile(
    r"^\s*(?:Section\s+)?(\d+[A-Za-z]?|[IVXLC]+)\.?\s+",
    re.IGNORECASE,
)
_ARTICLE_RE = re.compile(r"^\s*Article\s+(\d+[A-Za-z]?)\.?\s+", re.IGNORECASE)


def split_into_clauses(raw_text: str) -> list[SplitClause]:
    text = raw_text.replace("\r\n", "\n").strip()
    if not text:
        return []

    lines = text.split("\n")
    sections: list[SplitClause] = []
    current_num: str | None = None
    current_heading: str | None = None
    current_body: list[str] = []

    def flush():
        nonlocal current_body
        if current_body and (current_num or current_heading):
            sections.append(
                SplitClause(
                    section_number=current_num,
                    heading=current_heading,
                    text="\n".join(current_body).strip(),
                )
            )
        elif current_body:
            sections.append(
                SplitClause(section_number=None, heading=None, text="\n".join(current_body).strip())
            )
        current_body = []

    for line in lines:
        art = _ARTICLE_RE.match(line)
        sec = _SECTION_RE.match(line) if not art else None
        m = art or sec
        if m:
            flush()
            current_num = f"Article {m.group(1)}" if art else m.group(1)
            rest = line[m.end():].strip()
            current_heading = rest.split(".")[0][:120] if rest else None
            current_body = [line.strip()]
        else:
            current_body.append(line)
    flush()

    if not sections:
        blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
        return [SplitClause(None, None, b) for b in blocks]

    return sections
