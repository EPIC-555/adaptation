import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import init_db
from app.jobs import runner as job_runner
from app.routers import (
    health, auth, sources, bills, analysis, findings, review, audit_log,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    job_runner.start()
    try:
        yield
    finally:
        job_runner.stop()


def create_app() -> FastAPI:
    app = FastAPI(title="Rights Regression Radar - Backend", lifespan=lifespan)

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"] if settings.app_env == "development" else [],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    for r in (health.router, auth.router, sources.router, bills.router,
              analysis.router, findings.router, review.router, audit_log.router):
        app.include_router(r)

    return app


app = create_app()
