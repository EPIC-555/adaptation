from datetime import datetime
from typing import Optional, Literal
from pydantic import BaseModel, EmailStr, Field

Label = Literal["conflicts", "removes_safeguard", "consistent", "unrelated"]


# ---- Auth ----
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)


class UserOut(BaseModel):
    id: str
    email: EmailStr
    role: str
    class Config: from_attributes = True


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ---- Source docs ----
class ClauseOut(BaseModel):
    id: str
    source_document_id: str
    section_number: Optional[str] = None
    heading: Optional[str] = None
    text: str
    order_index: int
    class Config: from_attributes = True


class SourceDocumentCreate(BaseModel):
    act_name: str
    jurisdiction: str = "IN"
    status: str = "in_force"
    version_label: str = "v1"
    effective_date: Optional[datetime] = None
    source_url: Optional[str] = None
    provenance_note: Optional[str] = None
    raw_text: str


class SourceDocumentOut(BaseModel):
    id: str
    act_name: str
    jurisdiction: str
    status: str
    version_label: str
    effective_date: Optional[datetime]
    retrieved_at: datetime
    source_url: Optional[str]
    class Config: from_attributes = True


# ---- Bills ----
class BillOut(BaseModel):
    id: str
    title: str
    status: str
    created_at: datetime
    class Config: from_attributes = True


class BillClauseOut(BaseModel):
    id: str
    bill_id: str
    section_number: Optional[str] = None
    heading: Optional[str] = None
    text: str
    order_index: int
    class Config: from_attributes = True


# ---- Jobs ----
class JobOut(BaseModel):
    id: str
    bill_id: str
    status: str
    error: Optional[str] = None
    started_at: Optional[datetime]
    completed_at: Optional[datetime]
    created_at: datetime
    class Config: from_attributes = True


# ---- Findings ----
class RetrievedProvisionOut(BaseModel):
    id: str
    source_clause_id: str
    score: Optional[float]
    rank: int
    source_clause: ClauseOut
    class Config: from_attributes = True


class FindingOut(BaseModel):
    id: str
    job_id: str
    bill_id: str
    bill_clause_id: str
    bill_clause: BillClauseOut
    predicted_label: Optional[Label]
    confidence: Optional[float]
    insufficient_evidence: bool
    fundamental_right_tags: list[str] = []
    human_required: bool
    explanation: Optional[str]
    created_at: datetime
    retrieved: list[RetrievedProvisionOut] = []
    class Config: from_attributes = True


class ReviewActionCreate(BaseModel):
    decision: Literal["confirm", "reject", "relabel"]
    new_label: Optional[Label] = None
    note: Optional[str] = None


class ReviewActionOut(BaseModel):
    id: str
    finding_id: str
    reviewer_id: str
    decision: str
    new_label: Optional[str]
    note: Optional[str]
    created_at: datetime
    class Config: from_attributes = True


class AuditLogOut(BaseModel):
    id: str
    entity_type: str
    entity_id: str
    actor_id: Optional[str]
    action: str
    previous_value: Optional[dict]
    new_value: Optional[dict]
    note: Optional[str]
    created_at: datetime
    class Config: from_attributes = True
