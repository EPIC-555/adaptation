import uuid
from datetime import datetime
from sqlalchemy import (
    String, Text, DateTime, ForeignKey, Integer, Float, JSON, Boolean, Index
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.database import Base


def _uuid() -> str:
    return str(uuid.uuid4())


def _now() -> datetime:
    return datetime.utcnow()


# ---------- Users ----------
class User(Base):
    __tablename__ = "users"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    email: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String, nullable=False)
    role: Mapped[str] = mapped_column(String, default="reviewer")  # "reviewer" | "admin"
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


# ---------- Source legal documents (the "old" corpus) ----------
class SourceDocument(Base):
    """
    An existing / historical Indian legal document used as evidence.
    Version-aware: multiple rows may share the same act_name but different
    versions / dates / status.
    """
    __tablename__ = "source_documents"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    act_name: Mapped[str] = mapped_column(String, index=True, nullable=False)
    jurisdiction: Mapped[str] = mapped_column(String, default="IN")
    status: Mapped[str] = mapped_column(
        String, default="in_force"
    )  # in_force | repealed | proposed | not_commenced | amended
    version_label: Mapped[str] = mapped_column(String, default="v1")
    effective_date: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    retrieved_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    source_url: Mapped[str | None] = mapped_column(String, nullable=True)
    provenance_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    raw_text: Mapped[str | None] = mapped_column(Text, nullable=True)

    clauses: Mapped[list["Clause"]] = relationship(
        back_populates="source_document", cascade="all, delete-orphan"
    )


class Clause(Base):
    """A legally meaningful clause/section extracted from a SourceDocument."""
    __tablename__ = "clauses"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    source_document_id: Mapped[str] = mapped_column(
        ForeignKey("source_documents.id", ondelete="CASCADE"), index=True
    )
    section_number: Mapped[str | None] = mapped_column(String, index=True)
    heading: Mapped[str | None] = mapped_column(String, nullable=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    order_index: Mapped[int] = mapped_column(Integer, default=0)

    source_document: Mapped["SourceDocument"] = relationship(back_populates="clauses")
    __table_args__ = (
        Index("ix_clause_doc_order", "source_document_id", "order_index"),
    )


# ---------- Bills (the "new" proposed documents) ----------
class Bill(Base):
    __tablename__ = "bills"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    title: Mapped[str] = mapped_column(String, nullable=False)
    uploaded_by: Mapped[str] = mapped_column(ForeignKey("users.id"))
    filename: Mapped[str | None] = mapped_column(String, nullable=True)
    file_path: Mapped[str | None] = mapped_column(String, nullable=True)
    status: Mapped[str] = mapped_column(String, default="uploaded")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)

    clauses: Mapped[list["BillClause"]] = relationship(
        back_populates="bill", cascade="all, delete-orphan"
    )


class BillClause(Base):
    __tablename__ = "bill_clauses"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), index=True)
    section_number: Mapped[str | None] = mapped_column(String, nullable=True)
    heading: Mapped[str | None] = mapped_column(String, nullable=True)
    text: Mapped[str] = mapped_column(Text, nullable=False)
    order_index: Mapped[int] = mapped_column(Integer, default=0)

    bill: Mapped["Bill"] = relationship(back_populates="clauses")


# ---------- Analysis jobs ----------
class AnalysisJob(Base):
    __tablename__ = "analysis_jobs"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String, default="queued")
    error: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
    created_by: Mapped[str] = mapped_column(ForeignKey("users.id"))


class Finding(Base):
    __tablename__ = "findings"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    job_id: Mapped[str] = mapped_column(ForeignKey("analysis_jobs.id", ondelete="CASCADE"), index=True)
    bill_id: Mapped[str] = mapped_column(ForeignKey("bills.id", ondelete="CASCADE"), index=True)
    bill_clause_id: Mapped[str] = mapped_column(ForeignKey("bill_clauses.id", ondelete="CASCADE"))

    predicted_label: Mapped[str | None] = mapped_column(String, nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    insufficient_evidence: Mapped[bool] = mapped_column(Boolean, default=False)

    fundamental_right_tags: Mapped[list | None] = mapped_column(JSON, default=list)

    human_required: Mapped[bool] = mapped_column(Boolean, default=True)
    explanation: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class RetrievedProvision(Base):
    """Evidence linking a finding to a specific source Clause."""
    __tablename__ = "retrieved_provisions"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    finding_id: Mapped[str] = mapped_column(ForeignKey("findings.id", ondelete="CASCADE"), index=True)
    source_clause_id: Mapped[str] = mapped_column(ForeignKey("clauses.id", ondelete="CASCADE"))
    score: Mapped[float | None] = mapped_column(Float, nullable=True)
    rank: Mapped[int] = mapped_column(Integer, default=0)


# ---------- Human review ----------
class ReviewAction(Base):
    __tablename__ = "review_actions"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    finding_id: Mapped[str] = mapped_column(ForeignKey("findings.id", ondelete="CASCADE"), index=True)
    reviewer_id: Mapped[str] = mapped_column(ForeignKey("users.id"))
    decision: Mapped[str] = mapped_column(String)  # confirm | reject | relabel
    new_label: Mapped[str | None] = mapped_column(String, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[str] = mapped_column(String, primary_key=True, default=_uuid)
    entity_type: Mapped[str] = mapped_column(String, index=True)
    entity_id: Mapped[str] = mapped_column(String, index=True)
    actor_id: Mapped[str | None] = mapped_column(String, nullable=True)
    action: Mapped[str] = mapped_column(String)
    previous_value: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    new_value: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=_now)
