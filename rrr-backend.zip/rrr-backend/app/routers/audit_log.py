from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import AuditLog, User
from app.schemas import AuditLogOut
from app.deps import require_admin

router = APIRouter(prefix="/api/audit-log", tags=["audit-log"])


@router.get("", response_model=list[AuditLogOut])
def list_audit(entity_type: str | None = None, entity_id: str | None = None,
               limit: int = 200, db: Session = Depends(get_db),
               _: User = Depends(require_admin)):
    stmt = select(AuditLog).order_by(AuditLog.created_at.desc()).limit(min(limit, 1000))
    if entity_type:
        stmt = stmt.where(AuditLog.entity_type == entity_type)
    if entity_id:
        stmt = stmt.where(AuditLog.entity_id == entity_id)
    return list(db.execute(stmt).scalars())
