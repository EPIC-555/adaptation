from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import SourceDocument, Clause, User
from app.schemas import SourceDocumentCreate, SourceDocumentOut, ClauseOut
from app.security import get_current_user
from app.clause_splitter import split_into_clauses
from app.audit import log

router = APIRouter(prefix="/api/sources", tags=["sources"])


@router.get("", response_model=list[SourceDocumentOut])
def list_sources(q: str | None = None, db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    stmt = select(SourceDocument)
    if q:
        stmt = stmt.where(SourceDocument.act_name.ilike(f"%{q}%"))
    return list(db.execute(stmt.order_by(SourceDocument.act_name)).scalars())


@router.post("", response_model=SourceDocumentOut)
def create_source(payload: SourceDocumentCreate, db: Session = Depends(get_db),
                  user: User = Depends(get_current_user)):
    doc = SourceDocument(
        act_name=payload.act_name,
        jurisdiction=payload.jurisdiction,
        status=payload.status,
        version_label=payload.version_label,
        effective_date=payload.effective_date,
        source_url=payload.source_url,
        provenance_note=payload.provenance_note,
        raw_text=payload.raw_text,
    )
    db.add(doc)
    db.flush()

    for idx, sc in enumerate(split_into_clauses(payload.raw_text)):
        db.add(Clause(
            source_document_id=doc.id,
            section_number=sc.section_number,
            heading=sc.heading,
            text=sc.text,
            order_index=idx,
        ))
    log(db, entity_type="source", entity_id=doc.id, actor_id=user.id,
        action="created", new={"act_name": doc.act_name, "status": doc.status})
    db.commit()
    db.refresh(doc)
    return doc


@router.get("/{doc_id}/clauses", response_model=list[ClauseOut])
def list_clauses(doc_id: str, db: Session = Depends(get_db),
                 _: User = Depends(get_current_user)):
    doc = db.get(SourceDocument, doc_id)
    if not doc:
        raise HTTPException(404, "Source document not found")
    return list(db.execute(
        select(Clause).where(Clause.source_document_id == doc_id).order_by(Clause.order_index)
    ).scalars())
