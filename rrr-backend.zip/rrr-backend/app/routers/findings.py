from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Finding, ReviewAction, User, Bill
from app.schemas import ReviewActionCreate, ReviewActionOut
from app.deps import require_reviewer
from app.audit import log

router = APIRouter(prefix="/api/findings", tags=["findings-review"])


@router.post("/{finding_id}/review", response_model=ReviewActionOut)
def review(finding_id: str, payload: ReviewActionCreate,
           db: Session = Depends(get_db), user: User = Depends(require_reviewer)):
    f = db.get(Finding, finding_id)
    if not f:
        raise HTTPException(404, "Finding not found")
    bill = db.get(Bill, f.bill_id)
    if not bill:
        raise HTTPException(404, "Bill not found")

    if payload.decision == "relabel" and not payload.new_label:
        raise HTTPException(400, "new_label is required for relabel")

    prev = {"predicted_label": f.predicted_label, "human_required": f.human_required}

    action = ReviewAction(
        finding_id=f.id, reviewer_id=user.id,
        decision=payload.decision, new_label=payload.new_label, note=payload.note,
    )
    db.add(action)

    if payload.decision == "relabel":
        f.predicted_label = payload.new_label
        f.insufficient_evidence = False
    f.human_required = False

    log(db, entity_type="finding", entity_id=f.id, actor_id=user.id,
        action=payload.decision, previous=prev,
        new={"predicted_label": f.predicted_label, "new_label": payload.new_label},
        note=payload.note)
    db.commit()
    db.refresh(action)
    return action


@router.get("/{finding_id}/reviews", response_model=list[ReviewActionOut])
def list_reviews(finding_id: str, db: Session = Depends(get_db),
                 _: User = Depends(require_reviewer)):
    f = db.get(Finding, finding_id)
    if not f:
        raise HTTPException(404, "Finding not found")
    return list(db.execute(
        select(ReviewAction).where(ReviewAction.finding_id == finding_id)
        .order_by(ReviewAction.created_at)
    ).scalars())
