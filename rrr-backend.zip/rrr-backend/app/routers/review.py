from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Finding, User
from app.schemas import FindingOut
from app.deps import require_reviewer
from app.routers.analysis import _hydrate

router = APIRouter(prefix="/api/review-queue", tags=["review-queue"])


@router.get("", response_model=list[FindingOut])
def queue(db: Session = Depends(get_db), _: User = Depends(require_reviewer)):
    """Findings requiring human review. Ordered oldest first."""
    rows = list(db.execute(
        select(Finding).where(Finding.human_required == True)  # noqa: E712
        .order_by(Finding.created_at)
    ).scalars())
    return _hydrate(db, rows)
