import os
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.models import Bill, BillClause, User
from app.schemas import BillOut, BillClauseOut
from app.security import get_current_user
from app.clause_splitter import split_into_clauses
from app.audit import log

router = APIRouter(prefix="/api/bills", tags=["bills"])

ALLOWED_EXT = {".txt", ".md"}


@router.get("", response_model=list[BillOut])
def list_bills(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return list(db.execute(
        select(Bill).where(Bill.uploaded_by == user.id).order_by(Bill.created_at.desc())
    ).scalars())


@router.post("", response_model=BillOut)
async def upload_bill(
    title: str = Form(...),
    notes: str | None = Form(None),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in ALLOWED_EXT:
        raise HTTPException(400, f"Unsupported file type. Allowed: {sorted(ALLOWED_EXT)}")

    contents = await file.read()
    if len(contents) > settings.max_upload_bytes:
        raise HTTPException(413, "File too large")
    try:
        text = contents.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(400, "File must be UTF-8 encoded text")

    bill = Bill(title=title, uploaded_by=user.id, filename=file.filename, status="parsing", notes=notes)
    db.add(bill)
    db.flush()

    stored_path = os.path.join(settings.upload_dir, f"{bill.id}{ext}")
    with open(stored_path, "wb") as f:
        f.write(contents)
    bill.file_path = stored_path

    for idx, sc in enumerate(split_into_clauses(text)):
        db.add(BillClause(
            bill_id=bill.id,
            section_number=sc.section_number,
            heading=sc.heading,
            text=sc.text,
            order_index=idx,
        ))
    bill.status = "parsed"
    log(db, entity_type="bill", entity_id=bill.id, actor_id=user.id,
        action="uploaded", new={"title": title, "filename": file.filename})
    db.commit()
    db.refresh(bill)
    return bill


@router.get("/{bill_id}", response_model=BillOut)
def get_bill(bill_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    bill = db.get(Bill, bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Bill not found")
    return bill


@router.get("/{bill_id}/clauses", response_model=list[BillClauseOut])
def bill_clauses(bill_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    bill = db.get(Bill, bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Bill not found")
    return list(db.execute(
        select(BillClause).where(BillClause.bill_id == bill_id).order_by(BillClause.order_index)
    ).scalars())
