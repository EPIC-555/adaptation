from fastapi import APIRouter
from app.ml_adapter import ML_ADAPTER, StubMLAdapter

router = APIRouter(tags=["health"])


@router.get("/health")
def health():
    return {
        "ok": True,
        "ml_configured": not isinstance(ML_ADAPTER, StubMLAdapter),
    }
