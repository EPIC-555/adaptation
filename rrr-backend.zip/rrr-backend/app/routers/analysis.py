from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import (
    Bill, AnalysisJob, Finding, User, BillClause
)
from app.schemas import JobOut, FindingOut, RetrievedProvisionOut
from app.security import get_current_user
from app.audit import log

router = APIRouter(prefix="/api", tags=["analysis"])


@router.post("/bills/{bill_id}/analyze", response_model=JobOut)
def start_analysis(bill_id: str, db: Session = Depends(get_db),
                   user: User = Depends(get_current_user)):
    bill = db.get(Bill, bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Bill not found")
    if not bill.clauses:
        raise HTTPException(400, "Bill has no clauses to analyse")

    active = db.execute(
        select(AnalysisJob).where(
            AnalysisJob.bill_id == bill_id,
            AnalysisJob.status.in_(["queued", "running"]),
        )
    ).scalar_one_or_none()
    if active:
        raise HTTPException(409, "An analysis job is already running for this bill")

    job = AnalysisJob(bill_id=bill_id, status="queued", created_by=user.id)
    bill.status = "analysis_queued"
    db.add(job)
    log(db, entity_type="job", entity_id=job.id, actor_id=user.id,
        action="queued", new={"bill_id": bill_id})
    db.commit()
    db.refresh(job)
    return job


@router.get("/jobs/{job_id}", response_model=JobOut)
def get_job(job_id: str, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    job = db.get(AnalysisJob, job_id)
    if not job:
        raise HTTPException(404, "Job not found")
    bill = db.get(Bill, job.bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Job not found")
    return job


@router.get("/bills/{bill_id}/summary")
def bill_summary(bill_id: str, db: Session = Depends(get_db),
                 user: User = Depends(get_current_user)):
    """
    Bill Health Summary. Counts are computed from real Finding rows only.
    If no analysis has been run, all counts are zero.
    """
    bill = db.get(Bill, bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Bill not found")

    total_clauses = db.execute(
        select(func.count()).select_from(BillClause).where(BillClause.bill_id == bill_id)
    ).scalar_one()

    latest_job = db.execute(
        select(AnalysisJob).where(AnalysisJob.bill_id == bill_id)
        .order_by(AnalysisJob.created_at.desc())
    ).scalars().first()

    counts = {"conflicts": 0, "removes_safeguard": 0, "consistent": 0, "unrelated": 0,
              "insufficient_evidence": 0}
    if latest_job and latest_job.status == "completed":
        rows = db.execute(
            select(Finding.predicted_label, Finding.insufficient_evidence,
                   func.count()).where(Finding.job_id == latest_job.id)
            .group_by(Finding.predicted_label, Finding.insufficient_evidence)
        ).all()
        for label, insuff, n in rows:
            key = "insufficient_evidence" if insuff or label is None else label
            counts[key] = counts.get(key, 0) + n

    analyzed = sum(counts.values())
    pct = {k: (round(v * 100.0 / analyzed, 2) if analyzed else 0.0) for k, v in counts.items()}

    return {
        "bill_id": bill_id,
        "status": bill.status,
        "total_clauses": total_clauses,
        "analyzed_clauses": analyzed,
        "counts": counts,
        "percentages": pct,
        "latest_job": JobOut.model_validate(latest_job).model_dump() if latest_job else None,
    }


@router.get("/bills/{bill_id}/findings", response_model=list[FindingOut])
def list_findings(bill_id: str, db: Session = Depends(get_db),
                  user: User = Depends(get_current_user)):
    bill = db.get(Bill, bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Bill not found")
    findings = list(db.execute(
        select(Finding).where(Finding.bill_id == bill_id).order_by(Finding.created_at)
    ).scalars())
    return _hydrate(db, findings)


@router.get("/findings/{finding_id}", response_model=FindingOut)
def get_finding(finding_id: str, db: Session = Depends(get_db),
                user: User = Depends(get_current_user)):
    f = db.get(Finding, finding_id)
    if not f:
        raise HTTPException(404, "Finding not found")
    bill = db.get(Bill, f.bill_id)
    if not bill or bill.uploaded_by != user.id:
        raise HTTPException(404, "Finding not found")
    return _hydrate(db, [f])[0]


def _hydrate(db: Session, findings: list[Finding]) -> list[FindingOut]:
    from app.models import RetrievedProvision, Clause
    out = []
    for f in findings:
        rps = list(db.execute(
            select(RetrievedProvision).where(RetrievedProvision.finding_id == f.id)
            .order_by(RetrievedProvision.rank)
        ).scalars())
        retrieved = []
        for rp in rps:
            clause = db.get(Clause, rp.source_clause_id)
            retrieved.append(RetrievedProvisionOut(
                id=rp.id, source_clause_id=rp.source_clause_id,
                score=rp.score, rank=rp.rank,
                source_clause=clause,
            ))
        fo = FindingOut.model_validate(f)
        fo.retrieved = retrieved
        out.append(fo)
    return out
