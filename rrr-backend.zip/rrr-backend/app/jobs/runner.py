"""
Minimal DB-backed job runner. Starts a daemon thread that polls
`analysis_jobs` for queued rows and processes them.

Replace with Celery/RQ later by swapping this module; job semantics
(queued -> running -> completed|failed) stay identical.
"""
import logging
import threading
from datetime import datetime

from sqlalchemy import select
from app.config import settings
from app.database import SessionLocal
from app.models import AnalysisJob, Bill, Finding, RetrievedProvision
from app.ml_adapter import ML_ADAPTER
from app.retrieval import get_retrieval

log = logging.getLogger("rrr.jobs")
_stop = threading.Event()
_thread: threading.Thread | None = None


def _process(job_id: str) -> None:
    db = SessionLocal()
    try:
        job = db.get(AnalysisJob, job_id)
        if not job or job.status != "queued":
            return
        job.status = "running"
        job.started_at = datetime.utcnow()
        bill = db.get(Bill, job.bill_id)
        if not bill:
            job.status = "failed"
            job.error = "Bill missing"
            db.commit()
            return
        bill.status = "analysis_running"
        db.commit()

        retriever = get_retrieval()

        for bc in bill.clauses:
            found = retriever.retrieve(db, bc.text, k=5)
            evidence_clauses = [r.clause for r in found]
            cls = ML_ADAPTER.classify(bc, evidence_clauses)
            tags = ML_ADAPTER.tag_fundamental_rights(bc) or []

            finding = Finding(
                job_id=job.id,
                bill_id=bill.id,
                bill_clause_id=bc.id,
                predicted_label=None if cls.insufficient_evidence else cls.label,
                confidence=cls.confidence,
                insufficient_evidence=cls.insufficient_evidence,
                fundamental_right_tags=tags,
                human_required=True if tags else (cls.insufficient_evidence or cls.confidence < 0.75),
                explanation=cls.explanation,
            )
            db.add(finding)
            db.flush()
            for rank, r in enumerate(found):
                db.add(RetrievedProvision(
                    finding_id=finding.id,
                    source_clause_id=r.clause.id,
                    score=r.score,
                    rank=rank,
                ))

        bill.status = "analysis_completed"
        job.status = "completed"
        job.completed_at = datetime.utcnow()
        db.commit()
        log.info("Job %s completed", job_id)

    except Exception as e:
        log.exception("Job %s failed", job_id)
        db.rollback()
        try:
            job = db.get(AnalysisJob, job_id)
            if job:
                job.status = "failed"
                job.error = str(e)[:1000]
                job.completed_at = datetime.utcnow()
                db.commit()
        except Exception:
            log.exception("Failed to mark job failed")
    finally:
        db.close()


def _loop() -> None:
    while not _stop.is_set():
        try:
            db = SessionLocal()
            try:
                ids = [
                    r[0]
                    for r in db.execute(
                        select(AnalysisJob.id).where(AnalysisJob.status == "queued").limit(5)
                    ).all()
                ]
            finally:
                db.close()
            for jid in ids:
                _process(jid)
        except Exception:
            log.exception("Job loop error")
        _stop.wait(settings.job_poll_seconds)


def start() -> None:
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, name="rrr-job-runner", daemon=True)
    _thread.start()


def stop() -> None:
    _stop.set()
