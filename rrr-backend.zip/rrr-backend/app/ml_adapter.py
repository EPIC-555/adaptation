"""
ML adapter contract.

The analysis job calls `MLAdapter.classify` for each (bill_clause, retrieved)
pair and `MLAdapter.tag_fundamental_rights` per bill clause.

No ML is implemented here. StubMLAdapter intentionally returns
insufficient_evidence=True so the backend never fabricates predictions.
When your model is ready, subclass MLAdapter, import your libs, and set
`ML_ADAPTER` below to your class instance.
"""
from dataclasses import dataclass
from app.models import BillClause, Clause


LABELS = ("conflicts", "removes_safeguard", "consistent", "unrelated")


@dataclass
class Classification:
    label: str
    confidence: float
    explanation: str
    insufficient_evidence: bool = False


class MLAdapter:
    def classify(self, bill_clause: BillClause, evidence: list[Clause]) -> Classification:
        raise NotImplementedError

    def tag_fundamental_rights(self, bill_clause: BillClause) -> list[str]:
        raise NotImplementedError


class StubMLAdapter(MLAdapter):
    """
    Deliberately unimplemented. The analysis pipeline will mark every finding
    as insufficient_evidence and route it to human review, which is the
    correct behaviour when no model is installed.
    """

    def classify(self, bill_clause: BillClause, evidence: list[Clause]) -> Classification:
        return Classification(
            label="unrelated",
            confidence=0.0,
            explanation="ML model not configured; routed to human review.",
            insufficient_evidence=True,
        )

    def tag_fundamental_rights(self, bill_clause: BillClause) -> list[str]:
        return []


ML_ADAPTER: MLAdapter = StubMLAdapter()
