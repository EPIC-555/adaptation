"""Tests for clause splitting, amendment parsing, dataset integrity and metrics."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rrr.ingest.amendments import find_target_act, parse_amendments
from rrr.ingest.clauses import split_into_clauses
from rrr.ml.metrics import LABELS, compute
from rrr.retrieval.index import BM25Index


# --- clause splitting --------------------------------------------------------

def test_splits_numbered_sections():
    text = (
        "1. Short title and commencement. This Act may be called the Test Act.\n"
        "2. Definitions. In this Act, unless the context otherwise requires, the "
        "following words shall have the meanings assigned to them and nothing else.\n"
        "3. Application. It shall apply to every person within the territory of India.\n"
    )
    clauses = split_into_clauses(text)
    nums = [c.section_number for c in clauses]
    assert "1" in nums and "2" in nums and "3" in nums


def test_alphanumeric_section_numbers():
    text = ("12A. Special provision. Notwithstanding anything contained in section 12, "
            "the Central Government may by notification specify the manner of compliance "
            "with the said provision in respect of such classes of persons as may be "
            "prescribed under the rules made under this Act for the said purpose.\n")
    clauses = split_into_clauses(text)
    assert any(c.section_number == "12A" for c in clauses)


def test_empty_text_yields_no_clauses():
    assert split_into_clauses("") == []


# --- amendment parsing -------------------------------------------------------

def test_finds_target_act():
    text = "An Act further to amend the Banking Regulation Act, 1949."
    name, year = find_target_act(text)
    assert name == "Banking Regulation Act, 1949"
    assert year == 1949


def test_omission_reference_and_sections():
    text = ("An Act further to amend the Test Act, 1960. In the principal Act, "
            "in section 5, sub-section (3) shall be omitted.")
    ins = parse_amendments(text)
    omit = [i for i in ins if i.kind == "omission"]
    assert omit, "expected an omission instruction"
    assert omit[0].section_numbers == ["5"]
    assert omit[0].ref_type == "sub_section"
    assert omit[0].target_act == "Test Act, 1960"


def test_omission_of_proviso_detected():
    text = ("An Act further to amend the Test Act, 1960. In section 12 of the principal "
            "Act, the second proviso shall be omitted.")
    ins = parse_amendments(text)
    omit = [i for i in ins if i.kind == "omission"]
    assert omit and omit[0].ref_type == "proviso"
    assert omit[0].section_numbers == ["12"]


def test_word_substitution_captures_both_quotes():
    text = ('An Act further to amend the Test Act, 1960. In section 3, for the words '
            '\u201cten lakh rupees\u201d, the words \u201cone crore rupees\u201d shall be '
            'substituted.')
    ins = parse_amendments(text)
    ws = [i for i in ins if i.kind == "word_substitution"]
    assert ws, "expected a word substitution"
    assert ws[0].quoted_old == "ten lakh rupees"
    assert ws[0].quoted_new == "one crore rupees"


def test_range_expansion():
    text = ("An Act further to amend the Test Act, 1960. Sections 15A to 18 of the "
            "principal Act shall be omitted.")
    ins = parse_amendments(text)
    omit = [i for i in ins if i.kind == "omission"]
    assert omit[0].section_numbers == ["15", "16", "17", "18"]


# --- metrics -----------------------------------------------------------------

def test_perfect_predictions_score_one():
    y = list(LABELS) * 3
    m = compute("perfect", y, y)
    assert m.accuracy == 1.0
    assert m.macro_f1 == pytest.approx(1.0)


def test_confusion_matrix_is_square_and_counts_all():
    y_true = ["conflicts", "consistent", "conflicts", "unrelated"]
    y_pred = ["conflicts", "unrelated", "consistent", "unrelated"]
    m = compute("m", y_true, y_pred)
    assert m.n == 4
    assert len(m.confusion) == len(LABELS)
    assert all(len(row) == len(LABELS) for row in m.confusion)
    assert sum(sum(r) for r in m.confusion) == 4
    assert m.accuracy == pytest.approx(0.5)


def test_macro_f1_penalises_missing_class():
    y_true = ["conflicts"] * 4 + ["consistent"] * 4
    y_pred = ["conflicts"] * 8  # never predicts consistent
    m = compute("m", y_true, y_pred)
    assert m.per_class["consistent"]["recall"] == 0.0
    assert m.macro_f1 < 0.7


# --- retrieval ---------------------------------------------------------------

def test_bm25_finds_exact_clause():
    idx = BM25Index()
    idx.add({"clause_id": "a", "text": "the controller shall publish the annual report"})
    idx.add({"clause_id": "b", "text": "the board shall appoint a chief executive officer"})
    idx.add({"clause_id": "c", "text": "penalties for contravention of the licensing rules"})
    idx.finalize()
    hits = idx.search("annual report publication by the controller", k=1)
    assert hits and hits[0].clause_id == "a"


def test_bm25_empty_query_returns_nothing():
    idx = BM25Index()
    idx.add({"clause_id": "a", "text": "some statutory text here"})
    idx.finalize()
    assert idx.search("", k=3) == []


# --- dataset integrity (only when artifacts exist) ---------------------------

PAIRS = Path("data/pairs.jsonl")


@pytest.mark.skipif(not PAIRS.exists(), reason="dataset not built")
def test_dataset_splits_are_balanced_and_document_separated():
    rows = [json.loads(l) for l in open(PAIRS)]
    assert rows

    from collections import Counter, defaultdict
    counts = Counter((r["split"], r["label"]) for r in rows)
    for split in ("train", "val", "test"):
        n = {lab: counts[(split, lab)] for lab in LABELS}
        assert len(set(n.values())) == 1, f"unbalanced {split}: {n}"

    doc_split = defaultdict(set)
    for r in rows:
        doc_split[r["new_doc_id"]].add(r["split"])
        doc_split[r["old_doc_id"]].add(r["split"])
    leaked = {d: s for d, s in doc_split.items() if len(s) > 1}
    assert not leaked, f"documents appear in multiple splits: {list(leaked)[:5]}"


@pytest.mark.skipif(not PAIRS.exists(), reason="dataset not built")
def test_every_pair_has_provenance_and_rationale():
    for line in open(PAIRS):
        r = json.loads(line)
        assert r["label"] in LABELS
        assert r["rationale"].strip()
        assert r["provenance_type"]
        assert r["new_text"].strip() and r["old_text"].strip()
        assert r["new_doc_id"] and r["old_doc_id"]
