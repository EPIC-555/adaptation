"""Tests for the difficulty breakdown and the tokenizer guard."""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from rrr.ml.subgroups import _distinctive, classify_pairs, jaccard

PAIRS = Path("data/pairs.jsonl")


def test_distinctive_drops_boilerplate():
    text = "National Waterway 14 Baitarni River near the village"
    assert "baitarni" in _distinctive(text)
    assert "waterway" not in _distinctive(text)
    assert "village" not in _distinctive(text)


def test_template_twins_land_in_template_group():
    rows = [{
        "old_text": "14. National Waterway 14 Baitarni River: Dattapur village at Lat 20N",
        "new_text": "65. National Waterway 65 Mahananda River: Gosaipur at Lat 25N",
    }]
    groups = classify_pairs(rows)
    assert len(groups["template_only"]) == 1
    assert groups["substantive"] == []


def test_substantive_pair_lands_in_substantive_group():
    rows = [{
        "old_text": "The licensee shall give fifteen days notice before disconnecting "
                    "the supply of electricity to a consumer.",
        "new_text": "The licensee shall give thirty days notice before disconnecting "
                    "the supply of electricity to a consumer.",
    }]
    groups = classify_pairs(rows)
    assert len(groups["substantive"]) == 1


def test_jaccard_edge_cases():
    assert jaccard(set(), set()) == 0.0
    assert jaccard({"a"}, {"a"}) == 1.0
    assert jaccard({"a"}, {"b"}) == 0.0


@pytest.mark.skipif(not PAIRS.exists(), reason="dataset not built")
def test_subgroup_split_covers_every_test_pair():
    rows = [json.loads(l) for l in open(PAIRS) if json.loads(l)["split"] == "test"]
    groups = classify_pairs(rows)
    total = sum(len(v) for v in groups.values())
    assert total == len(rows)
