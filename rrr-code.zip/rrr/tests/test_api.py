"""API tests. The retrieval and health endpoints run against the real corpus;
the classification endpoints are skipped unless a trained model is present."""
from __future__ import annotations

from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from rrr.api.service import app

MODEL_DIR = Path("artifacts/deberta-v3-small-rrr")
has_model = MODEL_DIR.exists() and any(MODEL_DIR.glob("*.safetensors")) or \
            any(MODEL_DIR.glob("pytorch_model.bin"))
needs_model = pytest.mark.skipif(not has_model, reason="model not trained yet")


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


def test_health_reports_components(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    assert body["index_loaded"] is True
    assert body["corpus_clauses"] > 1000


def test_retrieve_returns_evidence_with_provenance(client):
    r = client.post("/retrieve", json={"query": "personal data shall be erased", "k": 3})
    assert r.status_code == 200
    results = r.json()["results"]
    assert results
    for hit in results:
        assert hit["text"].strip()
        assert hit["clause_id"]
        assert hit["filename"]


def test_retrieve_rejects_short_query(client):
    assert client.post("/retrieve", json={"query": "ab", "k": 3}).status_code == 422


@needs_model
def test_classify_returns_distribution_over_four_labels(client):
    r = client.post("/classify", json={
        "new_text": "The licensee shall not give notice before disconnecting supply.",
        "old_text": "Provided that the licensee shall give fifteen days notice before "
                    "disconnecting supply.",
    })
    assert r.status_code == 200
    body = r.json()
    assert body["label"] in ("conflicts", "removes_safeguard", "consistent", "unrelated")
    assert set(body["probabilities"]) == {
        "conflicts", "removes_safeguard", "consistent", "unrelated"}
    assert abs(sum(body["probabilities"].values()) - 1.0) < 0.01
    assert 0.0 <= body["confidence"] <= 1.0
    assert isinstance(body["needs_review"], bool)


@needs_model
def test_analyze_attaches_evidence_to_every_finding(client):
    r = client.post("/analyze", json={
        "new_text": "Personal data shall be processed only with the consent of the "
                    "data principal and shall be erased once the purpose is fulfilled.",
        "k": 3,
    })
    assert r.status_code == 200
    findings = r.json()["findings"]
    assert findings
    for f in findings:
        assert f["evidence"]["clause_id"]
        assert f["evidence"]["filename"]
        assert f["evidence"]["text"].strip()


@needs_model
def test_metrics_endpoint_serves_the_report(client):
    r = client.get("/metrics")
    assert r.status_code == 200
    rows = r.json()
    assert any("DeBERTa" in row["model"] for row in rows)
