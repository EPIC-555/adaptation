"""Drop-in adapters for the existing Rights Regression Radar backend.

Copy this file to `app/ml_adapter_rrr.py` in the backend and set at the bottom
of `app/ml_adapter.py`:

    from app.ml_adapter_rrr import RRRMLAdapter
    ML_ADAPTER = RRRMLAdapter()

and in `app/retrieval.py`:

    from app.ml_adapter_rrr import RRRRetrieval
    _default = RRRRetrieval()

Both satisfy the interfaces already defined in that backend, so the job runner,
endpoints and database models are untouched.

Findings below the calibrated threshold are returned with
`insufficient_evidence=True` so the existing pipeline routes them to human
review rather than presenting them as settled.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path

# Path to this repository's source tree. Override with RRR_HOME if the backend
# is deployed elsewhere.
RRR_HOME = Path(os.environ.get("RRR_HOME", "/workspace/rrr"))
if str(RRR_HOME / "src") not in sys.path:
    sys.path.insert(0, str(RRR_HOME / "src"))

from rrr.infer import PairClassifier                       # noqa: E402
from rrr.retrieval.index import BM25Index                  # noqa: E402
from app.ml_adapter import MLAdapter, Classification       # noqa: E402
from app.retrieval import RetrievalAdapter, Retrieved      # noqa: E402

_MODEL_DIR = RRR_HOME / "artifacts" / "deberta-v3-small-rrr"
_CALIBRATION = RRR_HOME / "artifacts" / "calibration.json"
_CLAUSES = RRR_HOME / "data" / "clauses.jsonl"

# Constitutional keywords mapped to the Articles they engage. Rule based and
# deterministic: every tag cites a specific Article rather than an opinion.
_RIGHTS_MAP: list[tuple[str, tuple[str, ...]]] = [
    ("Article 14 (equality before law)", (
        "discriminat", "equality", "arbitrary", "equal protection", "class legislation")),
    ("Article 19(1)(a) (freedom of speech and expression)", (
        "speech", "expression", "press", "publication", "broadcast",
        "information", "censorship")),
    ("Article 19(1)(c) (freedom of association)", (
        "association", "union", "collective", "membership")),
    ("Article 19(1)(g) (freedom to practise a profession or trade)", (
        "trade", "business", "profession", "occupation", "commerce", "industry")),
    ("Article 21 (life and personal liberty)", (
        "personal liberty", "life", "privacy", "livelihood", "dignity",
        "health", "detention", "arrest", "bodily")),
    ("Article 21A (right to education)", ("education", "school", "pupil", "student")),
    ("Article 25 (freedom of religion)", ("religion", "religious", "worship")),
    ("Article 32 (constitutional remedies)", (
        "writ", "supreme court", "constitutional remedy", "habeas")),
    ("Article 300A (property rights)", (
        "property", "acquisition", "compensation", "requisition")),
]


@dataclass
class _AdapterState:
    classifier: PairClassifier | None = None
    index: BM25Index | None = None
    loaded: bool = False


_state = _AdapterState()


def _ensure_loaded() -> None:
    if _state.loaded:
        return
    if _MODEL_DIR.exists():
        _state.classifier = PairClassifier(str(_MODEL_DIR), str(_CALIBRATION))
    if _CLAUSES.exists():
        _state.index = BM25Index.from_jsonl(str(_CLAUSES))
    _state.loaded = True


class RRRMLAdapter(MLAdapter):
    """Four-class relationship classifier over (bill clause, evidence) pairs."""

    def classify(self, bill_clause, evidence: list) -> Classification:
        _ensure_loaded()
        if _state.classifier is None or not evidence:
            return Classification(
                label="unrelated", confidence=0.0,
                explanation="Model not loaded or no evidence retrieved; "
                            "routed to human review.",
                insufficient_evidence=True,
            )

        # The backend may pass several retrieved clauses; use the closest one.
        first = evidence[0]
        old_text = getattr(first, "text", None) or first["text"]
        pred = _state.classifier.classify(bill_clause.text, old_text)

        return Classification(
            label=pred.label,
            confidence=pred.confidence,
            explanation=pred.explanation,
            insufficient_evidence=pred.needs_review,
        )

    def tag_fundamental_rights(self, bill_clause) -> list[str]:
        text = (getattr(bill_clause, "text", "") or "").lower()
        return [article for article, kws in _RIGHTS_MAP
                if any(k in text for k in kws)]


class RRRRetrieval(RetrievalAdapter):
    """BM25 retrieval over the statute corpus, keyed by clause text."""

    def retrieve(self, db, query: str, k: int = 5) -> list[Retrieved]:
        _ensure_loaded()
        if _state.index is None:
            return []
        from sqlalchemy import select
        from app.models import Clause

        out: list[Retrieved] = []
        for h in _state.index.search(query, k=k):
            clause = db.execute(
                select(Clause).where(Clause.text == h.text).limit(1)
            ).scalars().first()
            if clause is not None:
                out.append(Retrieved(clause=clause, score=float(h.score)))
        return out
