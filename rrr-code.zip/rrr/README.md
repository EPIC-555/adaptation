# Rights Regression Radar

Detects when a proposed provision weakens a protection that existing Indian law
already grants, and shows the exact source text that supports the finding.

Four-class relationship classifier over `(existing provision, proposed provision)`:

| label | meaning |
|---|---|
| `conflicts` | the proposal negates or contradicts an existing obligation |
| `removes_safeguard` | the proposal drops a protection present in existing law |
| `consistent` | the proposal restates or refines existing law |
| `unrelated` | the two provisions do not bear on each other |

## Evidence rules

These are enforced by the pipeline, not by convention.

1. Every clause in the corpus carries its source filename, document id, section
   number and a SHA-256 of the source PDF. Nothing is generated.
2. Training labels come from deterministic rules applied to real legislative
   text (see `docs/LABELS.md`). No language model produced a label.
3. The classifier never emits a citation. Citations come from the retrieval
   layer, which returns clause ids that exist in `data/clauses.jsonl`.
4. Predictions below the calibrated threshold are marked for human review
   instead of being presented as settled.

## Reproduce

```bash
python -m venv .venv && . .venv/bin/activate
pip install -e .

./run_pipeline.sh            # ingest -> dataset -> baselines -> train -> report
./run_pipeline.sh --fast     # everything except training
```

Serve the API and the demo page:

```bash
PYTHONPATH=src python -m uvicorn rrr.api.service:app --host 0.0.0.0 --port 8000
# demo page at http://localhost:8000/demo
```

## Results

Held-out test split, 260 pairs (65 per class):

| Model | Accuracy | Macro-F1 |
|---|---|---|
| **DeBERTa-v3 cross-encoder (fine-tuned)** | **0.965** | **0.965** |
| TF-IDF + logistic regression | 0.631 | 0.560 |
| Zero-shot NLI (`nli-deberta-v3-small`) | 0.408 | 0.321 |
| Majority class | 0.250 | 0.100 |

The zero-shot model predicts `removes_safeguard` zero times — an off-the-shelf
NLI model has no such label — which is why fine-tuning is required rather than
convenient. Full analysis, including the limitations and the weak `consistent`
class, is in `docs/EVALUATION.md`.

## Show the results

```bash
PYTHONPATH=src python -m rrr.demo --compare   # model vs baselines table
PYTHONPATH=src python -m rrr.demo --demo      # worked examples with provenance
PYTHONPATH=src python -m rrr.ml.subgroups     # accuracy by pair difficulty
```

`reports/REPORT.md` is generated from the predictions; every number in it was
computed by `rrr.ml.metrics` on the held-out test split.

If training is interrupted once validation stops improving, finalise from the
best checkpoint instead of retraining:

```bash
PYTHONPATH=src python -m rrr.ml.finalize \
  --checkpoint artifacts/deberta-v3-small-rrr/checkpoint-173
```

## Layout

```
src/rrr/ingest/      PDF extraction, clause splitting, amendment parsing
src/rrr/ml/          dataset construction, baselines, training, metrics, calibration,
                     finalize (export a checkpoint), subgroups (difficulty breakdown)
src/rrr/retrieval/   BM25 and dense retrievers, retrieval evaluation
src/rrr/api/         FastAPI service
src/rrr/infer.py     shared inference path used by API and CLI
integration/         drop-in adapters for the existing FastAPI backend
api_demo/            demonstration page
tests/               unit and dataset-integrity tests
```

## Evaluation protocol

The test set is locked before training and never inspected during development.

- splits are assigned per source **document**, so no document contributes to
  more than one split; pairs whose two documents fall in different splits are
  dropped rather than reassigned
- classes are balanced within each split
- the same test split scores the fine-tuned model, TF-IDF + logistic regression,
  zero-shot NLI, and a majority-class reference
- the review threshold is chosen on the validation split only, then reported on
  the test split

Details and the reasoning behind the label rules: `docs/LABELS.md`.
Interface details: `docs/ARCHITECTURE.md`.
