# AGENTS.md

## What this is

Rights Regression Radar: given a provision from a new bill and an existing
provision, decide whether the new one `conflicts`, `removes_safeguard`, is
`consistent`, or is `unrelated`, and cite the real source text for the decision.

Package root is this directory. Source lives in `src/rrr/` (src layout), so
commands need `PYTHONPATH=src`. Use the venv at
`/workspace/project/adaptation/.venv/bin/python`; the default python lacks
fastapi.

## Commands

```bash
PYTHONPATH=src python -m pytest tests/ -q                 # 26 tests, ~7s
PYTHONPATH=src python -m rrr.demo --compare               # model vs baselines
PYTHONPATH=src python -m rrr.ml.subgroups                 # accuracy by difficulty
PYTHONPATH=src python -m rrr.ml.report                    # regenerate REPORT.md
PYTHONPATH=src python -m uvicorn rrr.api.service:app --port 8000
./run_pipeline.sh                                         # full rebuild (hours)
```

## Invariants to keep

**Evidence first.** Every finding carries Act, section, version, date and the
`doc_id`/`clause_id` it came from. Nothing is quoted that is not in the corpus.
If a field is unknown, it is null, not guessed.

**Never evaluate on test while tuning.** The test split is fixed. The checkpoint
is chosen by validation macro-F1; the review threshold is chosen on validation;
test is read once, to report.

**All numbers come from `rrr.ml.metrics`.** Baselines, the fine-tuned model and
the zero-shot model are scored by the same code from raw predictions. Do not
hand-compute a metric in a notebook and paste it into a report.

**Split by document, not by pair.** A clause must not appear in training and
test at once. `build_dataset` enforces this; keep it that way.

## Traps already hit

**Tokenizer mismatch is silent and fatal.** `Trainer.save_model` does not save
the tokenizer, and the saved `config.json` drops `_name_or_path`. A later
`AutoTokenizer.from_pretrained(checkpoint)` then quietly returns some other
tokenizer from the HF cache, and the model emits one class for every input while
looking confident. Two defences are in place: `SaveTokenizer` in `train.py`
writes the tokenizer into every checkpoint, and `check_tokenizer` in
`finalize.py` (reused by `infer.py`) refuses to load a tokenizer whose vocabulary
cannot belong to the model. If a model predicts one label for everything, suspect
this before anything else.

**DeBERTa-v3 embedding rows exceed the tokenizer vocabulary.** 128,100 rows
against 128,000 tokens. An equality check on the two numbers is wrong and will
reject a correct model. Compare with the vocabulary able to fit, not equal to.

**The `consistent` class contains template twins.** Statutes such as the National
Waterways Act repeat one clause per river, differing only in proper nouns. Such
pairs share boilerplate, not subject matter, and 124 of 455 `consistent` pairs are
of this kind. They are why the cross-provision retrieval probe returns ~0: there
is no real partner to find. `rrr.ml.subgroups` measures the effect on accuracy;
do not quietly drop these pairs to make a number look better, report them.

**Cross-provision retrieval is unsolved.** BM25 and dense both score ~0 R@1 on it
because the probe is ill-posed, not because the retrievers are broken.
Self-retrieval is ~0.99 for both. Fix the `consistent` class before drawing
conclusions from that probe.

## Gotchas

- `artifacts/`, `data/` and `reports/` are gitignored. The model weights (568 MB)
  are not in git; rebuild with `run_pipeline.sh`, or finalise from an existing
  checkpoint.
- Training is CPU-only (`use_cpu=True`) and slow. Early stopping triggers around
  epoch 1-2. If interrupted, use `rrr.ml.finalize --checkpoint <dir>` rather than
  retraining.
- Dense retrieval evaluation is single-threaded and takes ~35 minutes; run it in
  the background and do not block on it.
- The API loads the classifier in a lifespan handler and degrades gracefully if
  the model is missing, so `/health` is the check that the model actually loaded.
