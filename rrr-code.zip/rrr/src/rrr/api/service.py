"""FastAPI service exposing the classifier and retrieval to the product.

Endpoints
    GET  /health          service and model status
    GET  /metrics         the evaluation report produced on the held-out test set
    POST /retrieve        BM25 retrieval over the statute corpus
    POST /classify        classify one (new, old) provision pair
    POST /analyze         retrieve evidence, then classify the strongest matches

Every response that carries a finding includes the source filename, section and
verbatim text so the frontend never renders a claim without its evidence.
"""
from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from rrr.infer import PairClassifier
from rrr.retrieval.index import BM25Index

log = logging.getLogger("rrr.api")

DATA_DIR = Path("data")
ART_DIR = Path("artifacts")

_state: dict = {}


def _load() -> None:
    """Load the corpus index and the model. A missing or half-written model
    directory must not take the service down; the API reports what is available
    via /health and returns 503 on the endpoints that need the model."""
    index_path = DATA_DIR / "clauses.jsonl"
    _state["index"] = BM25Index.from_jsonl(str(index_path)) if index_path.exists() else None

    model_dir = ART_DIR / "deberta-v3-small-rrr"
    _state["classifier"] = None
    if model_dir.exists():
        try:
            _state["classifier"] = PairClassifier(
                str(model_dir), str(ART_DIR / "calibration.json")
            )
        except Exception as exc:
            log.warning("model at %s could not be loaded: %s", model_dir, exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    _load()
    yield


app = FastAPI(title="Rights Regression Radar", version="0.1.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

if Path("api_demo").is_dir():
    app.mount("/demo", StaticFiles(directory="api_demo", html=True), name="demo")


class RetrieveRequest(BaseModel):
    query: str = Field(..., min_length=3)
    k: int = Field(5, ge=1, le=50)


class ClassifyRequest(BaseModel):
    new_text: str = Field(..., min_length=10)
    old_text: str = Field(..., min_length=10)


class AnalyzeRequest(BaseModel):
    new_text: str = Field(..., min_length=10)
    k: int = Field(5, ge=1, le=20)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "classifier_loaded": _state.get("classifier") is not None,
        "index_loaded": _state.get("index") is not None,
        "corpus_clauses": len(_state["index"].docs) if _state.get("index") else 0,
    }


@app.get("/metrics")
def metrics() -> list[dict]:
    p = ART_DIR.parent / "reports" / "metrics.json"
    if not p.exists():
        raise HTTPException(404, "no evaluation report yet; run the training pipeline")
    return json.loads(p.read_text())


@app.post("/retrieve")
def retrieve(req: RetrieveRequest) -> dict:
    index = _state.get("index")
    if index is None:
        raise HTTPException(503, "corpus index not loaded")
    return {"query": req.query, "results": [h.to_dict() for h in index.search(req.query, req.k)]}


@app.post("/classify")
def classify(req: ClassifyRequest) -> dict:
    clf = _state.get("classifier")
    if clf is None:
        raise HTTPException(503, "model not loaded; train it first")
    return clf.classify(req.new_text, req.old_text).to_dict()


@app.post("/analyze")
def analyze(req: AnalyzeRequest) -> dict:
    """Retrieve candidate evidence for a proposed provision and classify each."""
    index, clf = _state.get("index"), _state.get("classifier")
    if index is None or clf is None:
        raise HTTPException(503, "model or index not loaded")

    findings = []
    for hit in index.search(req.new_text, req.k):
        pred = clf.classify(req.new_text, hit.text)
        findings.append({
            "label": pred.label,
            "confidence": pred.confidence,
            "probabilities": pred.probabilities,
            "needs_review": pred.needs_review,
            "explanation": pred.explanation,
            "evidence": {
                "clause_id": hit.clause_id,
                "text": hit.text,
                "title": hit.title,
                "section_number": hit.section_number,
                "filename": hit.filename,
                "source_path": hit.source_path,
                "retrieval_score": round(hit.score, 4),
            },
        })
    findings.sort(key=lambda f: (not f["needs_review"], -f["confidence"]))
    return {"new_text": req.new_text, "findings": findings}
