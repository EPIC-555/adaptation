"""Command-line demo. Two modes:

  --compare   print the model-versus-baseline table on the held-out test split
  --demo      classify real held-out examples and show the cited evidence

Both read the same artifacts the API serves, so what is shown here is what the
product shows.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from rrr.ml.metrics import compute
from rrr.retrieval.index import BM25Index


def cmd_compare(args) -> None:
    model = json.load(open(args.model_preds))
    base = json.load(open(args.baseline_preds))
    y_true = model["y_true"]

    results = [compute("DeBERTa-v3 cross-encoder (fine-tuned)", y_true, model["y_pred"])]
    results.append(compute("TF-IDF + logistic regression", y_true, base["tfidf_logreg"]))
    if "zeroshot_nli" in base:
        results.append(compute("Zero-shot NLI (no fine-tuning)", y_true, base["zeroshot_nli"]))
    from collections import Counter
    maj = Counter(y_true).most_common(1)[0][0]
    results.append(compute("Majority class", y_true, [maj] * len(y_true)))

    print(f"\nHeld-out test split: {len(y_true)} pairs "
          f"({len(y_true)//4} per class)\n")
    print(f"{'model':42s} {'accuracy':>9s} {'macro-F1':>9s}")
    print("-" * 62)
    for r in results:
        print(f"{r.model:42s} {r.accuracy:9.3f} {r.macro_f1:9.3f}")

    best = max(results[1:], key=lambda r: r.macro_f1)
    ours = results[0]
    print(f"\nbest baseline: {best.model} (macro-F1 {best.macro_f1:.3f})")
    print(f"fine-tuned model: macro-F1 {ours.macro_f1:.3f} "
          f"({ours.macro_f1 - best.macro_f1:+.3f} vs best baseline)")

    print("\nPer-class recall for the fine-tuned model:")
    for lab in ours.labels:
        d = ours.per_class[lab]
        print(f"  {lab:20s} P {d['precision']:.3f}  R {d['recall']:.3f}  F1 {d['f1']:.3f}")


def cmd_demo(args) -> None:
    from rrr.infer import PairClassifier
    rows = [json.loads(l) for l in open(args.pairs)]
    test = [r for r in rows if r["split"] == "test"]

    clf = PairClassifier(args.model_dir, args.calibration)
    index = BM25Index.from_jsonl(args.clauses) if Path(args.clauses).exists() else None

    by_label = {}
    for r in test:
        by_label.setdefault(r["label"], r)

    correct = 0
    for lab, r in by_label.items():
        pred = clf.classify(r["new_text"], r["old_text"])
        ok = pred.label == r["label"]
        correct += ok
        print(f"\n{'='*78}")
        print(f"gold: {lab:18s} predicted: {pred.label:18s} "
              f"confidence {pred.confidence:.3f} {'OK' if ok else 'WRONG'}")
        print(f"provenance: {r['new_doc_id']} / {r['new_filename']} "
              f"section {r['new_section']}")
        print(f"  new_text: {r['new_text'][:200]}")
        print(f"  old_text: {r['old_text'][:200]}")
        print(f"  rationale: {r['rationale']}")
        if pred.needs_review:
            print("  -> routed to human review")

    print(f"\n{correct}/{len(by_label)} of these examples correct")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--compare", action="store_true")
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--model-preds", default="artifacts/model_predictions.json")
    ap.add_argument("--baseline-preds", default="artifacts/baseline_predictions.json")
    ap.add_argument("--pairs", default="data/pairs.jsonl")
    ap.add_argument("--clauses", default="data/clauses.jsonl")
    ap.add_argument("--model-dir", default="artifacts/deberta-v3-small-rrr")
    ap.add_argument("--calibration", default="artifacts/calibration.json")
    args = ap.parse_args()

    if args.compare:
        cmd_compare(args)
    elif args.demo:
        cmd_demo(args)
    else:
        ap.error("choose --compare or --demo")


if __name__ == "__main__":
    main()
