"""PDF text extraction with quality gating.

Born-digital PDFs extract cleanly; scanned ones yield no text. We detect the
latter and mark them ``needs_ocr`` rather than silently emitting empty clauses.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path

import pypdf

# Below this many characters per page a PDF is treated as image-only.
MIN_CHARS_PER_PAGE = 200


@dataclass
class Page:
    number: int  # 1-based
    text: str


@dataclass
class ExtractedDoc:
    path: str
    sha256: str
    n_pages: int
    pages: list[Page] = field(default_factory=list)
    needs_ocr: bool = False
    error: str | None = None

    @property
    def text(self) -> str:
        return "\n".join(p.text for p in self.pages)

    @property
    def chars_per_page(self) -> float:
        if not self.pages:
            return 0.0
        return len(self.text.strip()) / len(self.pages)


def _clean(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Rejoin words split by line-break hyphenation: "govern-\nment" -> "government"
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def extract_pdf(path: str | Path) -> ExtractedDoc:
    path = Path(path)
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    try:
        reader = pypdf.PdfReader(str(path))
        pages = [
            Page(number=i + 1, text=_clean(page.extract_text() or ""))
            for i, page in enumerate(reader.pages)
        ]
    except Exception as exc:  # malformed PDF must not crash the pipeline
        return ExtractedDoc(path=str(path), sha256=sha, n_pages=0, error=str(exc)[:300])

    doc = ExtractedDoc(path=str(path), sha256=sha, n_pages=len(pages), pages=pages)
    doc.needs_ocr = doc.chars_per_page < MIN_CHARS_PER_PAGE
    return doc
