"""Split statute text into sections, preserving numbering and headings.

Kept deliberately conservative: only line-leading section numbers start a new
clause, so quoted amendment text (indented, mid-line) does not fragment the
parent provision.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

# "1." / "1A." / "12B." at the start of a line, optionally "Section 1."
_SECTION_RE = re.compile(r"^\s*(?:Section\s+)?(\d{1,3}[A-Z]{0,2})\.\s+(?=[A-Z(])")
# Indian numbering also appears as "1. (1)" and "2. In the ..."
_ARTICLE_RE = re.compile(r"^\s*Article\s+(\d{1,3}[A-Z]?)\.\s+", re.IGNORECASE)
_CHAPTER_RE = re.compile(r"^\s*(CHAPTER|PART)\s+([IVXLC0-9]+)\s*$", re.IGNORECASE)

MIN_CLAUSE_CHARS = 40


@dataclass
class Clause:
    section_number: str | None
    heading: str | None
    text: str
    char_start: int = 0
    char_end: int = 0


def _heading_of(rest: str) -> str | None:
    """Extract a short heading from the text following a section number."""
    rest = rest.strip()
    if not rest:
        return None
    # "Short title and commencement.—(1) This Act may be called..."
    head = re.split(r"\.—|\.\s*\(|—", rest, maxsplit=1)[0].strip(" .—")
    if 3 <= len(head) <= 120 and not head[0].isdigit():
        return head
    return None


def split_into_clauses(raw_text: str) -> list[Clause]:
    text = raw_text.replace("\r\n", "\n").strip()
    if not text:
        return []

    clauses: list[Clause] = []
    current: Clause | None = None
    offset = 0

    def flush(end_offset: int) -> None:
        nonlocal current
        if current is not None:
            body = "\n".join(current.text.split("\n")).strip()
            if len(body) >= MIN_CLAUSE_CHARS:
                current.text = body
                current.char_end = end_offset
                clauses.append(current)
        current = None

    for line in text.split("\n"):
        line_len = len(line) + 1
        art = _ARTICLE_RE.match(line)
        sec = None if art else _SECTION_RE.match(line)
        chapter = _CHAPTER_RE.match(line)

        if chapter:
            flush(offset)
            current = Clause(section_number=None, heading=line.strip(), text=line.strip(),
                             char_start=offset)
        elif art or sec:
            flush(offset)
            m = art or sec
            num = f"Article {m.group(1)}" if art else m.group(1)
            rest = line[m.end():]
            current = Clause(section_number=num, heading=_heading_of(rest),
                             text=line.strip(), char_start=offset)
        elif current is not None:
            current.text += "\n" + line
        else:
            current = Clause(section_number=None, heading=None, text=line.strip(),
                             char_start=offset)
        offset += line_len

    flush(offset)

    if not clauses:
        blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
        return [Clause(None, None, b) for b in blocks if len(b) >= MIN_CLAUSE_CHARS]
    return clauses
