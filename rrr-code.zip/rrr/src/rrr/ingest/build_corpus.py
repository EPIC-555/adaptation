"""Build the clause-level corpus from a directory of statute PDFs.

Outputs (JSONL, one record per line):
  data/documents.jsonl  - one record per source PDF, with provenance + quality
  data/clauses.jsonl    - one record per extracted clause

Provenance is carried on every clause so the UI can always cite a real source.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from rrr.ingest.clauses import split_into_clauses
from rrr.ingest.pdf import extract_pdf

AMENDMENT_HINTS = ("amendment", "amend", "(a)act", "(a)_act", "ordinance", "repealing")


def _title_from_filename(name: str) -> str:
    stem = Path(name).stem
    stem = re.sub(r"[_\-]+", " ", stem)
    stem = re.sub(r"\s*\(\d+\)\s*$", "", stem)  # trailing " (1)" duplicates
    return re.sub(r"\s+", " ", stem).strip().title()


def _year_from_filename(name: str) -> int | None:
    years = re.findall(r"\b(19|20)\d{2}\b", name)
    found = re.findall(r"\b((?:19|20)\d{2})\b", name)
    return int(found[-1]) if found else None


def _is_amendment(name: str) -> bool:
    low = name.lower()
    return any(h in low for h in AMENDMENT_HINTS)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="/workspace/corpus")
    ap.add_argument("--out", default="data")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    pdfs = sorted(Path(args.corpus).glob("*.pdf"))
    print(f"found {len(pdfs)} PDFs")

    docs_f = (out / "documents.jsonl").open("w")
    clauses_f = (out / "clauses.jsonl").open("w")

    n_docs = n_clauses = n_ocr = n_err = 0
    for i, pdf in enumerate(pdfs, 1):
        doc = extract_pdf(pdf)
        doc_id = f"doc-{doc.sha256[:12]}"
        record = {
            "doc_id": doc_id,
            "filename": pdf.name,
            "title": _title_from_filename(pdf.name),
            "year": _year_from_filename(pdf.name),
            "is_amendment": _is_amendment(pdf.name),
            "n_pages": doc.n_pages,
            "chars_per_page": round(doc.chars_per_page, 1),
            "needs_ocr": doc.needs_ocr,
            "error": doc.error,
            "sha256": doc.sha256,
            "source_repo": "https://github.com/EPIC-555/adaptation",
            "source_path": pdf.name,
            "retrieved_date": "2026-10-29",
        }
        docs_f.write(json.dumps(record) + "\n")
        n_docs += 1
        if doc.error:
            n_err += 1
            continue
        if doc.needs_ocr:
            n_ocr += 1
            continue

        for ci, clause in enumerate(split_into_clauses(doc.text)):
            clauses_f.write(json.dumps({
                "clause_id": f"{doc_id}-c{ci:04d}",
                "doc_id": doc_id,
                "section_number": clause.section_number,
                "heading": clause.heading,
                "text": clause.text,
                "char_start": clause.char_start,
                "char_end": clause.char_end,
                "filename": pdf.name,
                "title": record["title"],
                "year": record["year"],
                "is_amendment": record["is_amendment"],
                "source_path": pdf.name,
            }) + "\n")
            n_clauses += 1

        if i % 25 == 0:
            print(f"  {i}/{len(pdfs)} docs, {n_clauses} clauses")

    docs_f.close()
    clauses_f.close()
    print(f"\ndocuments: {n_docs} (needs_ocr: {n_ocr}, errors: {n_err})")
    print(f"clauses:   {n_clauses}")


if __name__ == "__main__":
    main()
