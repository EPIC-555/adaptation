"""Parse Indian amendment Acts into structured amendment instructions.

Amendment Acts use a small, formal vocabulary. Extracting it yields labels that
come from the legislative text itself rather than from a model's guess:

    "sub-section (5) shall be omitted"                  -> omission
    "For section 19K, the following ... substituted"    -> substitution
    "the words "ten lakh rupees" shall be substituted"  -> word_substitution
    "shall be inserted"                                 -> insertion
    "section 3 ... shall be renumbered as sub-section"  -> renumbering

A structural change is *evidence* that an earlier provision was removed or
rewritten, not proof. We still require the target provision to exist in the
corpus before forming a training pair.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, asdict

# --- target Act resolution ---------------------------------------------------

_TARGET_ACT = re.compile(
    r"(?:further\s+to\s+amend|to\s+amend)\s+the\s+"
    r"([A-Z][A-Za-z,()\s\.\-]{2,110}?(?:Act|Code|Ordinance|Order)"
    r"[,\s]*\s*((?:19|20)\d{2}))",
    re.IGNORECASE,
)

# --- change-instruction patterns ---------------------------------------------

_OMIT = re.compile(r"([^.;]{0,220}?)\bshall\s+be\s+omitted\b", re.IGNORECASE | re.DOTALL)
_SUBST_SECTION = re.compile(
    r"for\s+(?:the\s+)?(sections?|sub-sections?|clauses?|provisos?|schedule)"
    r"\s+([^,]{1,120}?),?\s*the\s+following\s+[^,]{0,60}?shall\s+be\s+substituted",
    re.IGNORECASE | re.DOTALL,
)
_WORDS_SUBST = re.compile(
    r"for\s+the\s+words?\s*[\"'\u201c\u2018](.{2,400}?)[\"'\u201d\u2019]\s*,?\s*"
    r"the\s+words?\s*[\"'\u201c\u2018](.{0,400}?)[\"'\u201d\u2019]\s+shall\s+be\s+substituted",
    re.IGNORECASE | re.DOTALL,
)
_INSERT = re.compile(r"([^.;]{0,200}?)\bshall\s+be\s+inserted\b", re.IGNORECASE | re.DOTALL)
_RENUMBER = re.compile(r"([^.;]{0,160}?)\bshall\s+be\s+renumbered\b", re.IGNORECASE | re.DOTALL)

# --- reference parsing -------------------------------------------------------

_SECTION_REF = re.compile(
    r"sections?\s+((?:\d{1,3}[A-Z]{0,2})(?:\s*(?:,|and|to|and\s+to)\s*\d{1,3}[A-Z]{0,2})*)",
    re.IGNORECASE,
)
_SUBSECTION_REF = re.compile(r"sub-?sections?\s*\(([0-9A-Za-z]{1,4})\)", re.IGNORECASE)
_CLAUSE_REF = re.compile(r"clauses?\s*\(([0-9A-Za-z]{1,4})\)", re.IGNORECASE)
_PROVISO_REF = re.compile(r"\b((?:first|second|third|fourth|fifth)?\s*provisos?)\b", re.IGNORECASE)
_SCHEDULE_REF = re.compile(
    r"\b((?:first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)?\s*Schedules?)\b",
    re.IGNORECASE,
)
_NUM_TOKEN = re.compile(r"\b(\d{1,3})([A-Z]{0,2})\b")


@dataclass
class Instruction:
    kind: str                      # omission | substitution | word_substitution
                                   # | insertion | renumbering
    target_act: str | None
    target_year: int | None
    ref_type: str | None           # section | sub_section | clause | proviso | schedule
    ref_values: list[str]
    section_numbers: list[str]     # top-level sections named in the reference
    quoted_old: str | None
    quoted_new: str | None
    evidence_text: str
    char_start: int

    def to_dict(self) -> dict:
        return asdict(self)


def find_target_act(text: str) -> tuple[str | None, int | None]:
    """Resolve the principal Act an amendment Act modifies (search whole doc)."""
    m = _TARGET_ACT.search(text[:8000])
    if not m:
        return None, None
    return re.sub(r"\s+", " ", m.group(1)).strip(" ,"), int(m.group(2))


def _expand(raw: str) -> list[str]:
    """'15A to 17' -> ['15A','16','17']; '12, 13 and 14' -> ['12','13','14']."""
    out: list[str] = []
    for m in re.finditer(r"(\d{1,3})([A-Z]{0,2})\s+to\s+(\d{1,3})([A-Z]{0,2})", raw, re.I):
        s, e = int(m.group(1)), int(m.group(3))
        if 0 < s <= e <= s + 60:
            out.extend(str(n) for n in range(s, e + 1))
    if out:
        return sorted(set(out), key=lambda x: int(re.match(r"\d+", x).group()))
    toks = [f"{a}{b}" for a, b in _NUM_TOKEN.findall(raw)]
    return sorted(set(toks), key=lambda x: int(re.match(r"\d+", x).group()))


def _parse_ref(phrase: str) -> tuple[str | None, list[str], list[str]]:
    """Return (ref_type, ref_values, top_level_section_numbers).

    The reference nearest the end of the phrase is the direct object of the
    change ("... in section 5, sub-section (3) shall be omitted" omits the
    sub-section, not section 5). Section numbers are always captured separately
    so the target provision can still be located.
    """
    candidates: list[tuple[int, str, list[str]]] = []

    for m in _PROVISO_REF.finditer(phrase):
        candidates.append((m.end(), "proviso", [m.group(1).strip()]))
    for m in _SUBSECTION_REF.finditer(phrase):
        candidates.append((m.end(), "sub_section", [m.group(1)]))
    for m in _CLAUSE_REF.finditer(phrase):
        candidates.append((m.end(), "clause", [m.group(1)]))
    for m in _SCHEDULE_REF.finditer(phrase):
        candidates.append((m.end(), "schedule", [m.group(1).strip()]))
    for m in _SECTION_REF.finditer(phrase):
        candidates.append((m.end(), "section", _expand(m.group(1))))

    sec = _SECTION_REF.search(phrase)
    sections = _expand(sec.group(1)) if sec else []

    if not candidates:
        return None, [], sections
    pos, ref_type, values = max(candidates, key=lambda c: c[0])
    return ref_type, values, sections


def _mk(kind, phrase, evidence, pos, act, year, old=None, new=None) -> Instruction:
    ref_type, ref_vals, secs = _parse_ref(phrase)
    return Instruction(
        kind=kind, target_act=act, target_year=year,
        ref_type=ref_type, ref_values=ref_vals, section_numbers=secs,
        quoted_old=old, quoted_new=new,
        evidence_text=re.sub(r"\s+", " ", evidence).strip()[:600],
        char_start=pos,
    )


def parse_amendments(text: str, target_act: str | None = None,
                     target_year: int | None = None) -> list[Instruction]:
    """Extract amendment instructions from a full amendment-Act text."""
    if target_act is None:
        target_act, target_year = find_target_act(text)

    found: list[Instruction] = []
    flat = re.sub(r"\s+", " ", text)

    for m in _OMIT.finditer(flat):
        found.append(_mk("omission", m.group(1), m.group(0), m.start(),
                         target_act, target_year))
    for m in _SUBST_SECTION.finditer(flat):
        found.append(_mk("substitution", f"{m.group(1)} {m.group(2)}", m.group(0), m.start(),
                         target_act, target_year))
    for m in _WORDS_SUBST.finditer(flat):
        found.append(_mk("word_substitution", m.group(0), m.group(0), m.start(),
                         target_act, target_year, old=m.group(1).strip(), new=m.group(2).strip()))
    for m in _INSERT.finditer(flat):
        found.append(_mk("insertion", m.group(1), m.group(0), m.start(), target_act, target_year))
    for m in _RENUMBER.finditer(flat):
        found.append(_mk("renumbering", m.group(1), m.group(0), m.start(), target_act, target_year))

    found.sort(key=lambda i: i.char_start)
    return found
