"""Dense retriever using a sentence-transformer, as an alternative to BM25.

Legal provisions frequently express the same rule in different words, which is
exactly where lexical matching fails. This retriever embeds clauses and queries
into a shared space and ranks by cosine similarity. Embeddings are cached so
repeated evaluation and serving do not recompute them.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class DenseHit:
    clause_id: str
    score: float
    text: str
    title: str | None
    section_number: str | None
    filename: str | None
    source_path: str | None

    def to_dict(self) -> dict:
        return {
            "clause_id": self.clause_id,
            "score": round(float(self.score), 4),
            "text": self.text,
            "title": self.title,
            "section_number": self.section_number,
            "filename": self.filename,
            "source_path": self.source_path,
        }


class DenseIndex:
    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model_name)
        self.docs: list[dict] = []
        self.emb: np.ndarray | None = None

    @classmethod
    def build(cls, clauses_path: str, cache_path: str | None = None,
              model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
              max_docs: int | None = None) -> "DenseIndex":
        idx = cls(model_name)
        docs = []
        with open(clauses_path) as f:
            for i, line in enumerate(f):
                if max_docs is not None and i >= max_docs:
                    break
                docs.append(json.loads(line))
        idx.docs = docs
        cache = Path(cache_path) if cache_path else None
        if cache and cache.exists():
            idx.emb = np.load(cache)
            if len(idx.emb) == len(docs):
                return idx
        idx.emb = idx.model.encode([d.get("text", "") for d in docs],
                                   batch_size=64, show_progress_bar=True,
                                   normalize_embeddings=True, convert_to_numpy=True)
        if cache:
            cache.parent.mkdir(parents=True, exist_ok=True)
            np.save(cache, idx.emb)
        return idx

    def search(self, query: str, k: int = 5) -> list[DenseHit]:
        if self.emb is None or not len(self.docs):
            return []
        q = self.model.encode([query], normalize_embeddings=True, convert_to_numpy=True)[0]
        sims = self.emb @ q
        top = np.argsort(-sims)[:k]
        out = []
        for i in top:
            d = self.docs[int(i)]
            out.append(DenseHit(
                clause_id=d.get("clause_id", str(i)),
                score=float(sims[int(i)]),
                text=d.get("text", ""),
                title=d.get("title"),
                section_number=d.get("section_number"),
                filename=d.get("filename"),
                source_path=d.get("source_path"),
            ))
        return out
