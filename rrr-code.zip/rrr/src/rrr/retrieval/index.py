"""BM25 retrieval over the statutory clause corpus.

Deterministic, dependency-free and good at exact legal terminology, which is
what the evidence step needs. A dense retriever can be layered on later behind
the same interface.
"""
from __future__ import annotations

import json
import math
import re
from collections import Counter
from dataclasses import dataclass

_TOKEN = re.compile(r"[a-z0-9]+")
_STOP = set("""the of and or to in a is be shall may by for on any such under this that
with as from at it its not no if then than which who whom whose been being have has
had do does did will would can could should might must section act clause provided""".split())


def _tok(text: str) -> list[str]:
    return [w for w in _TOKEN.findall(text.lower()) if w not in _STOP and len(w) > 1]


@dataclass
class Hit:
    clause_id: str
    score: float
    text: str
    title: str | None
    section_number: str | None
    filename: str | None
    source_path: str | None

    def to_dict(self) -> dict:
        return {
            "clause_id": self.clause_id,
            "score": round(self.score, 4),
            "text": self.text,
            "title": self.title,
            "section_number": self.section_number,
            "filename": self.filename,
            "source_path": self.source_path,
        }


class BM25Index:
    def __init__(self, k1: float = 1.5, b: float = 0.75):
        self.k1, self.b = k1, b
        self.docs: list[dict] = []
        self.doc_tokens: list[Counter] = []
        self.doc_len: list[int] = []
        self.avg_len = 0.0
        self.postings: dict[str, list[tuple[int, int]]] = {}

    @classmethod
    def from_jsonl(cls, path: str, max_docs: int | None = None) -> "BM25Index":
        idx = cls()
        with open(path) as f:
            for i, line in enumerate(f):
                if max_docs is not None and i >= max_docs:
                    break
                idx.add(json.loads(line))
        idx.finalize()
        return idx

    def add(self, doc: dict) -> None:
        self.docs.append(doc)
        toks = _tok(doc.get("text", ""))
        self.doc_tokens.append(Counter(toks))
        self.doc_len.append(len(toks))

    def finalize(self) -> None:
        self.avg_len = (sum(self.doc_len) / len(self.doc_len)) if self.doc_len else 0.0
        postings: dict[str, list[tuple[int, int]]] = {}
        for i, tf in enumerate(self.doc_tokens):
            for term, n in tf.items():
                postings.setdefault(term, []).append((i, n))
        self.postings = postings

    def search(self, query: str, k: int = 5) -> list[Hit]:
        terms = _tok(query)
        if not terms or not self.docs:
            return []
        n = len(self.docs)
        scores = [0.0] * n
        for term in terms:
            plist = self.postings.get(term)
            if not plist:
                continue
            df = len(plist)
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            for i, tf in plist:
                dl = self.doc_len[i] or 1
                denom = tf + self.k1 * (1 - self.b + self.b * dl / (self.avg_len or 1))
                scores[i] += idf * (tf * (self.k1 + 1)) / denom
        top = sorted(range(n), key=lambda i: scores[i], reverse=True)[:k]
        out = []
        for i in top:
            if scores[i] <= 0:
                continue
            d = self.docs[i]
            out.append(Hit(
                clause_id=d.get("clause_id", str(i)),
                score=scores[i],
                text=d.get("text", ""),
                title=d.get("title"),
                section_number=d.get("section_number"),
                filename=d.get("filename"),
                source_path=d.get("source_path"),
            ))
        return out
