"""Retrieval evaluation: does the evidence step find the right source clause?

Two honest probes on the held-out test split:

  self    the query is the gold clause's own text; the clause must rank first.
          This measures the ceiling of the lexical retriever.
  cross   the query is the *other* provision of a `consistent` pair; the gold
          clause must appear in the top k. This measures whether retrieval finds
          related text across differently worded provisions, which is the harder
          and more realistic case.

Reported as Recall@1 and Recall@5.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from rrr.retrieval.index import BM25Index


def evaluate(index, queries: list[tuple[str, str]], k: int) -> dict:
    """queries: list of (query_text, gold_clause_id). Works with any index that
    exposes .search(text, k) returning objects with a .clause_id."""
    hits1 = hits5 = 0
    for text, gold_id in queries:
        results = index.search(text, k=k)
        ids = [h.clause_id for h in results]
        if ids and ids[0] == gold_id:
            hits1 += 1
        if gold_id in ids:
            hits5 += 1
    n = len(queries) or 1
    return {"n": len(queries), "recall_at_1": round(hits1 / n, 4),
            "recall_at_5": round(hits5 / n, 4)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--clauses", default="data/clauses.jsonl")
    ap.add_argument("--pairs", default="data/pairs.jsonl")
    ap.add_argument("--out", default="reports/retrieval_metrics.json")
    ap.add_argument("--dense", action="store_true", help="also evaluate a dense retriever")
    ap.add_argument("--dense-cache", default="artifacts/clause_embeddings.npy")
    args = ap.parse_args()

    bm25 = BM25Index.from_jsonl(args.clauses)
    by_id = {d["clause_id"]: d for d in bm25.docs}
    print(f"indexed {len(bm25.docs)} clauses")

    rows = [json.loads(l) for l in open(args.pairs)]
    test = [r for r in rows if r["split"] == "test"]

    self_q = [(d["text"], cid) for cid, d in by_id.items()
              if len(d.get("text", "")) >= 120]

    cross_q = []
    for r in test:
        if r["label"] != "consistent":
            continue
        old_id, new_id = _lookup(by_id, r["old_text"]), _lookup(by_id, r["new_text"])
        if old_id and new_id:
            cross_q.append((r["old_text"], new_id))
            cross_q.append((r["new_text"], old_id))

    out = {
        "indexed_clauses": len(bm25.docs),
        "bm25": {
            "self_retrieval": evaluate(bm25, self_q, k=5),
            "cross_provision_retrieval": evaluate(bm25, cross_q, k=5),
        },
    }

    if args.dense:
        from rrr.retrieval.dense import DenseIndex
        dense = DenseIndex.build(args.clauses, cache_path=args.dense_cache)
        out["dense_minilm"] = {
            "self_retrieval": evaluate(dense, self_q, k=5),
            "cross_provision_retrieval": evaluate(dense, cross_q, k=5),
        }

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))


def _norm(t: str) -> str:
    import re
    return re.sub(r"\s+", " ", t).strip()


def _lookup(by_id: dict, text: str) -> str | None:
    target = _norm(text)
    for cid, d in by_id.items():
        if _norm(d.get("text", "")) == target:
            return cid
    return None


if __name__ == "__main__":
    main()
