"""Combine model and baseline predictions into one comparison report.

Reads the prediction files written by `rrr.ml.train` and `rrr.ml.baselines`,
recomputes every metric from the raw predictions, and writes both a machine
readable JSON and a human readable Markdown report.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from rrr.ml.metrics import Metrics, compute, render_markdown, save_json, LABELS


def _load(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-preds", default="artifacts/model_predictions.json")
    ap.add_argument("--baseline-preds", default="artifacts/baseline_predictions.json")
    ap.add_argument("--out-json", default="reports/metrics.json")
    ap.add_argument("--out-md", default="reports/REPORT.md")
    args = ap.parse_args()

    model = _load(args.model_preds)
    base = _load(args.baseline_preds)

    y_true = model["y_true"]
    results: list[Metrics] = []

    results.append(compute("DeBERTa-v3 cross-encoder (fine-tuned)", y_true, model["y_pred"]))

    # Baselines must be scored against the same gold labels; verify alignment.
    if base["y_true"] != y_true:
        raise SystemExit("baseline and model predictions are not on the same test set")
    results.append(compute("TF-IDF + logistic regression", y_true, base["tfidf_logreg"]))
    if "zeroshot_nli" in base:
        results.append(compute("Zero-shot NLI (no fine-tuning)", y_true, base["zeroshot_nli"]))

    # Majority-class reference point.
    from collections import Counter
    majority = Counter(y_true).most_common(1)[0][0]
    results.append(compute("Majority class", y_true, [majority] * len(y_true)))

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    save_json(results, args.out_json)

    md = render_markdown(results)
    best = max(results[:-1], key=lambda r: r.macro_f1)
    md += ("\n\n## Headline\n\n"
           f"Highest macro-F1 on the held-out test split: **{best.model}** "
           f"at macro-F1 {best.macro_f1:.3f} and accuracy {best.accuracy:.3f} "
           f"over {best.n} pairs.\n")
    Path(args.out_md).write_text(md)
    print(md)
    print(f"\nwrote {args.out_json} and {args.out_md}")


if __name__ == "__main__":
    main()
