"""Confidence thresholds for routing findings to human review.

Thresholds are selected on the validation split to meet a stated operating
point: high recall on the two risk classes, because a missed regression is
costlier than a spurious flag. The chosen values are written to disk and used
by the inference service.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from rrr.ml.metrics import LABELS

RISK_LABELS = ("conflicts", "removes_safeguard")


def _recall_at(probs: np.ndarray, y_true: list[str], threshold: float) -> tuple[float, float]:
    """Coverage and risk-class recall when auto-accepting confident predictions."""
    pred = probs.argmax(axis=-1)
    conf = probs.max(axis=-1)
    auto = conf >= threshold
    idx = {lab: i for i, lab in enumerate(LABELS)}
    gold = np.array([idx[t] for t in y_true])

    if auto.sum() == 0:
        return 0.0, 0.0
    coverage = float(auto.mean())
    risk = np.isin(gold, [idx[l] for l in RISK_LABELS])
    caught = ((pred == gold) & auto & risk).sum()
    total_risk = risk.sum()
    return coverage, float(caught / total_risk) if total_risk else 0.0


def choose(val_probs: list[list[float]], val_true: list[str],
           target_risk_recall: float = 0.95) -> dict:
    probs = np.array(val_probs)
    chosen = None
    for t in np.arange(0.30, 0.99, 0.01):
        coverage, recall = _recall_at(probs, val_true, float(t))
        if recall >= target_risk_recall:
            chosen = (float(t), coverage, recall)
            break
    if chosen is None:
        t = 0.5
        coverage, recall = _recall_at(probs, val_true, t)
        chosen = (t, coverage, recall)
    return {
        "review_threshold": round(chosen[0], 3),
        "val_coverage": round(chosen[1], 4),
        "val_risk_recall": round(chosen[2], 4),
        "target_risk_recall": target_risk_recall,
        "risk_labels": list(RISK_LABELS),
        "policy": ("Predictions at or above the threshold are auto-accepted; anything "
                   "below is routed to human review. Threshold chosen on validation "
                   "data to keep recall on risk classes high."),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--model-preds", default="artifacts/model_predictions.json")
    ap.add_argument("--out", default="artifacts/calibration.json")
    ap.add_argument("--target", type=float, default=0.95)
    args = ap.parse_args()

    d = json.load(open(args.model_preds))
    cfg = choose(d["val_probs"], d["val_y_true"], args.target)

    # Report how the chosen threshold behaves on the held-out test split.
    probs = np.array(d["probs"])
    cov, rec = _recall_at(probs, d["y_true"], cfg["review_threshold"])
    cfg["test_coverage"] = round(cov, 4)
    cfg["test_risk_recall"] = round(rec, 4)

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(cfg, indent=2))
    print(json.dumps(cfg, indent=2))


if __name__ == "__main__":
    main()
