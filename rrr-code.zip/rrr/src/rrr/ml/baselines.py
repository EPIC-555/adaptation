"""Baselines evaluated on the same locked test split as the trained classifier.

1. TF-IDF + logistic regression over the concatenated pair text.
2. Zero-shot NLI cross-encoder. This is the honest "prompted pretrained model"
   baseline: an off-the-shelf NLI model has three labels (entailment, neutral,
   contradiction), so it cannot express `removes_safeguard` at all. The mapping
   below is the best available, and the resulting gap is a real finding, not a
   tuning failure.
"""
from __future__ import annotations

import argparse
import json

import numpy as np

from rrr.ml.metrics import LABELS

# NLI label -> our label. `removes_safeguard` is unreachable by construction.
NLI_TO_RRR = {"contradiction": "conflicts", "entailment": "consistent", "neutral": "unrelated"}


def load_pairs(path: str) -> list[dict]:
    return [json.loads(l) for l in open(path)]


def pair_text(row: dict) -> str:
    return f"{row['old_text']} [SEP] {row['new_text']}"


def run_tfidf(train: list[dict], test: list[dict], seed: int = 0):
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    from sklearn.pipeline import Pipeline

    pipe = Pipeline([
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 2), min_df=2, max_features=60000,
            sublinear_tf=True, lowercase=True,
        )),
        ("clf", LogisticRegression(max_iter=2000, C=4.0, class_weight="balanced",
                                   random_state=seed)),
    ])
    pipe.fit([pair_text(r) for r in train], [r["label"] for r in train])
    return pipe.predict([pair_text(r) for r in test]).tolist()


def run_zeroshot_nli(test: list[dict], model_name: str, batch_size: int = 8) -> list[str]:
    import torch
    from transformers import AutoModelForSequenceClassification, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(model_name)
    model.eval()
    id2label = model.config.id2label

    preds: list[str] = []
    with torch.no_grad():
        for i in range(0, len(test), batch_size):
            batch = test[i:i + batch_size]
            enc = tok(
                [r["old_text"] for r in batch],
                [r["new_text"] for r in batch],
                truncation=True, max_length=256, padding=True, return_tensors="pt",
            )
            logits = model(**enc).logits
            for row_logits in logits:
                lab = id2label[int(row_logits.argmax())]
                preds.append(NLI_TO_RRR.get(lab, "unrelated"))
    return preds


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="data/pairs.jsonl")
    ap.add_argument("--nli-model", default="cross-encoder/nli-deberta-v3-small")
    ap.add_argument("--out", default="artifacts/baseline_predictions.json")
    ap.add_argument("--skip-zeroshot", action="store_true")
    args = ap.parse_args()

    rows = load_pairs(args.pairs)
    train = [r for r in rows if r["split"] == "train"]
    test = [r for r in rows if r["split"] == "test"]
    print(f"train={len(train)} test={len(test)}")

    out = {"test_pair_ids": [r["pair_id"] for r in test],
           "y_true": [r["label"] for r in test]}

    print("running TF-IDF + logistic regression ...")
    out["tfidf_logreg"] = run_tfidf(train, test)

    if not args.skip_zeroshot:
        print(f"running zero-shot NLI ({args.nli_model}) ...")
        out["zeroshot_nli"] = run_zeroshot_nli(test, args.nli_model)

    with open(args.out, "w") as f:
        json.dump(out, f, indent=2)
    print("wrote", args.out)


if __name__ == "__main__":
    main()
