"""Build the four-class relationship dataset.

Substrate is real statutory text; labels come from documented, deterministic
rules rather than from a model's judgement:

  removes_safeguard  a real clause containing a proviso is paired with the same
                     clause with that proviso removed
  conflicts          a real obligation clause is paired with a negated variant
                     that cannot be complied with simultaneously
  consistent         two real clauses from the same Act on the same subject with
                     no opposing modality
  unrelated          two real clauses from different Acts sharing no subject

Splits are assigned per source document (never per pair), and pair counts are
balanced within each split so evaluation metrics are not dominated by one class.
Every pair carries provenance so the UI can cite real source text.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
from collections import defaultdict
from pathlib import Path

MAX_CLAUSE_CHARS = 1200
MIN_CLAUSE_CHARS = 120
MIN_PROVISO_CHARS = 40
LABELS = ("conflicts", "removes_safeguard", "consistent", "unrelated")

_NEGATIONS = [
    (r"\bshall\s+be\b", "shall not be"),
    (r"\bshall\b", "shall not"),
    (r"\bmay\s+be\b", "may not be"),
    (r"\bis\s+entitled\s+to\b", "is not entitled to"),
    (r"\bmay\b", "shall not"),
]
_ALREADY_NEGATED = re.compile(r"\b(not|no|nor|never|nothing)\b", re.IGNORECASE)
_PROVISO = re.compile(r"\bProvided\s+(?:further\s+)?that\b", re.IGNORECASE)

_STOP = set("""the of and or to in a is be shall may by for on any such under this that
with as from at it its his her their not no if then than which who whom whose been being
have has had do does did will would can could shall should may might must section act
sub-section clause sub clause provided that person persons government central state""".split())


def _tokens(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z]{3,}", text.lower()) if w not in _STOP}


def _jaccard(a: set[str], b: set[str]) -> float:
    return len(a & b) / len(a | b) if a and b else 0.0


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _negate(text: str) -> str | None:
    if _ALREADY_NEGATED.search(text):
        return None
    for pat, repl in _NEGATIONS:
        new, n = re.subn(pat, repl, text, count=1, flags=re.IGNORECASE)
        if n:
            return new
    return None


def _strip_proviso(text: str) -> str | None:
    m = _PROVISO.search(text)
    if not m:
        return None
    if len(text[m.start():].strip()) < MIN_PROVISO_CHARS:
        return None
    head = text[:m.start()].strip().rstrip(";,:— ").strip()
    return head if len(head) >= MIN_CLAUSE_CHARS else None


def _pid(*parts: str) -> str:
    return "pair-" + hashlib.sha256("|".join(parts).encode()).hexdigest()[:14]


def load_clauses(path: str) -> list[dict]:
    out = []
    for line in open(path):
        c = json.loads(line)
        text = _norm(c["text"])
        if MIN_CLAUSE_CHARS <= len(text) <= MAX_CLAUSE_CHARS:
            c["text"] = text
            out.append(c)
    return out


def assign_splits(docs: list[dict], seed: int = 0,
                  test_frac: float = 0.25, val_frac: float = 0.15) -> dict[str, str]:
    order = sorted(docs, key=lambda d: d["doc_id"])
    random.Random(seed).shuffle(order)
    n = len(order)
    n_test, n_val = int(n * test_frac), int(n * val_frac)
    return {
        d["doc_id"]: ("test" if i < n_test else "val" if i < n_test + n_val else "train")
        for i, d in enumerate(order)
    }


def _make_row(label, new_c, old_c, rationale, provenance, new_text, old_text) -> dict:
    return {
        "pair_id": _pid(label, _norm(new_text)[:200], _norm(old_text)[:200]),
        "new_text": _norm(new_text),
        "old_text": _norm(old_text),
        "label": label,
        "rationale": rationale,
        "provenance_type": provenance,
        "new_doc_id": new_c["doc_id"],
        "old_doc_id": old_c["doc_id"],
        "new_title": new_c.get("title"),
        "old_title": old_c.get("title"),
        "new_section": new_c.get("section_number"),
        "old_section": old_c.get("section_number"),
        "new_filename": new_c.get("filename"),
        "old_filename": old_c.get("filename"),
    }


def _candidates(label, clauses, by_doc, rng, cap):
    """Generate candidate rows of one class (document-agnostic; split applied later)."""
    out: list[dict] = []
    seen: set[str] = set()

    def push(row):
        if row["pair_id"] in seen:
            return
        if len(row["new_text"]) < MIN_CLAUSE_CHARS or len(row["old_text"]) < MIN_CLAUSE_CHARS:
            return
        seen.add(row["pair_id"])
        out.append(row)

    if label == "removes_safeguard":
        cand = [c for c in clauses if _PROVISO.search(c["text"])]
        rng.shuffle(cand)
        for c in cand:
            if len(out) >= cap:
                break
            head = _strip_proviso(c["text"])
            if head:
                push(_make_row(label, c, c,
                     "The new provision omits the proviso present in the earlier provision.",
                     "real_text_proviso_removed", head, c["text"]))

    elif label == "conflicts":
        cand = [c for c in clauses if not _ALREADY_NEGATED.search(c["text"])]
        rng.shuffle(cand)
        for c in cand:
            if len(out) >= cap:
                break
            neg = _negate(c["text"])
            if neg:
                push(_make_row(label, c, c,
                     "The new provision negates an obligation imposed by the earlier "
                     "provision; both cannot be complied with at once.",
                     "real_text_negated", neg, c["text"]))

    elif label == "consistent":
        doc_ids = sorted(by_doc)
        rng.shuffle(doc_ids)
        for doc_id in doc_ids:
            if len(out) >= cap:
                break
            cl = by_doc[doc_id]
            for _ in range(300):
                if len(out) >= cap:
                    break
                if len(cl) < 2:
                    break
                a, b = rng.sample(cl, 2)
                if a["text"] in b["text"] or b["text"] in a["text"]:
                    continue
                if _jaccard(_tokens(a["text"]), _tokens(b["text"])) < 0.12:
                    continue
                push(_make_row(label, a, b,
                     "Both provisions come from the same Act and address the same subject "
                     "without imposing opposing obligations.",
                     "real_text_same_act", a["text"], b["text"]))

    else:  # unrelated
        doc_ids = sorted(by_doc)
        rng.shuffle(doc_ids)
        for _ in range(cap * 80):
            if len(out) >= cap:
                break
            d1, d2 = rng.sample(doc_ids, 2)
            if d1 == d2 or not by_doc[d1] or not by_doc[d2]:
                continue
            a, b = rng.choice(by_doc[d1]), rng.choice(by_doc[d2])
            if _jaccard(_tokens(a["text"]), _tokens(b["text"])) > 0.05:
                continue
            push(_make_row(label, a, b,
                 "The provisions come from different Acts and share no relevant subject "
                 "matter, so no legal relationship is established.",
                 "real_text_cross_act", a["text"], b["text"]))
    return out


def build(clauses_path, docs_path, out_path, per_class, seed=0) -> dict:
    rng = random.Random(seed)
    clauses = load_clauses(clauses_path)
    docs = [json.loads(l) for l in open(docs_path)]
    splits = assign_splits(docs, seed)

    by_doc: dict[str, list[dict]] = defaultdict(list)
    for c in clauses:
        by_doc[c["doc_id"]].append(c)

    # Generate generously, then take a balanced number per (split, label).
    pool: list[dict] = []
    for label in LABELS:
        pool.extend(_candidates(label, clauses, by_doc, rng, cap=per_class * 4))

    # Usable only where both documents share a split.
    for r in pool:
        s_new, s_old = splits.get(r["new_doc_id"]), splits.get(r["old_doc_id"])
        r["split"] = s_new if s_new == s_old else None
    pool = [r for r in pool if r["split"]]

    buckets: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for r in pool:
        buckets[(r["split"], r["label"])].append(r)

    # Balance across labels within each split (smallest class sets the ceiling).
    final: list[dict] = []
    quota = {}
    for split in ("train", "val", "test"):
        available = {lab: len(buckets[(split, lab)]) for lab in LABELS}
        n = min(available.values()) if available else 0
        quota[split] = {lab: n for lab in LABELS}
        for lab in LABELS:
            chosen = buckets[(split, lab)][:n]
            for r in chosen:
                r["split"] = split
            final.extend(chosen)

    rng.shuffle(final)
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w") as f:
        for r in final:
            f.write(json.dumps(r) + "\n")

    counts = defaultdict(int)
    for r in final:
        counts[(r["split"], r["label"])] += 1
    return {
        "total": len(final),
        "per_split_label": {f"{k[0]}/{k[1]}": v for k, v in sorted(counts.items())},
        "quota_per_split_class": quota,
        "documents": len(docs),
        "clauses": len(clauses),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--clauses", default="data/clauses.jsonl")
    ap.add_argument("--documents", default="data/documents.jsonl")
    ap.add_argument("--out", default="data/pairs.jsonl")
    ap.add_argument("--per-class", type=int, default=700)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    print(json.dumps(build(args.clauses, args.documents, args.out,
                           args.per_class, args.seed), indent=2))


if __name__ == "__main__":
    main()
