"""Classification metrics and reporting shared by every model.

Kept dependency-light (numpy only) so the numbers shown in the UI come from the
same code path used to produce the evaluation report.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import numpy as np

LABELS = ("conflicts", "removes_safeguard", "consistent", "unrelated")


@dataclass
class Metrics:
    model: str
    n: int
    accuracy: float
    macro_f1: float
    per_class: dict[str, dict[str, float]] = field(default_factory=dict)
    confusion: list[list[int]] = field(default_factory=list)
    labels: tuple[str, ...] = LABELS

    def to_dict(self) -> dict:
        return {
            "model": self.model,
            "n": self.n,
            "accuracy": round(self.accuracy, 4),
            "macro_f1": round(self.macro_f1, 4),
            "per_class": {
                k: {m: round(v, 4) for m, v in d.items()} for k, d in self.per_class.items()
            },
            "confusion": self.confusion,
            "labels": list(self.labels),
        }


def compute(model_name: str, y_true: list[str], y_pred: list[str],
            labels: tuple[str, ...] = LABELS) -> Metrics:
    idx = {lab: i for i, lab in enumerate(labels)}
    k = len(labels)
    cm = np.zeros((k, k), dtype=int)
    for t, p in zip(y_true, y_pred):
        if t in idx and p in idx:
            cm[idx[t], idx[p]] += 1

    per_class: dict[str, dict[str, float]] = {}
    f1s = []
    for lab in labels:
        i = idx[lab]
        tp = int(cm[i, i])
        fp = int(cm[:, i].sum() - tp)
        fn = int(cm[i, :].sum() - tp)
        precision = tp / (tp + fp) if (tp + fp) else 0.0
        recall = tp / (tp + fn) if (tp + fn) else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        per_class[lab] = {
            "precision": precision, "recall": recall, "f1": f1,
            "support": int(cm[i, :].sum()),
        }
        f1s.append(f1)

    total = int(cm.sum())
    acc = float(np.trace(cm) / total) if total else 0.0
    return Metrics(model=model_name, n=total, accuracy=acc,
                   macro_f1=float(np.mean(f1s)) if f1s else 0.0,
                   per_class=per_class, confusion=cm.tolist(), labels=labels)


def render_markdown(results: list[Metrics]) -> str:
    lines = ["# Model evaluation\n",
             "All figures below were produced by `python -m rrr.ml.report` on the "
             "held-out test split. No estimated or placeholder values.\n"]
    lines.append("## Summary\n")
    lines.append("| Model | n | Accuracy | Macro-F1 |")
    lines.append("|---|---|---|---|")
    for r in results:
        lines.append(f"| {r.model} | {r.n} | {r.accuracy:.3f} | {r.macro_f1:.3f} |")

    for r in results:
        lines.append(f"\n## {r.model}\n")
        lines.append("| Class | Precision | Recall | F1 | Support |")
        lines.append("|---|---|---|---|---|")
        for lab in r.labels:
            d = r.per_class[lab]
            lines.append(f"| {lab} | {d['precision']:.3f} | {d['recall']:.3f} "
                         f"| {d['f1']:.3f} | {int(d['support'])} |")
        lines.append(f"\nAccuracy {r.accuracy:.3f} · Macro-F1 {r.macro_f1:.3f} · n={r.n}\n")
        lines.append("Confusion matrix (rows = gold, cols = predicted):\n")
        header = "| gold \\ pred | " + " | ".join(r.labels) + " |"
        lines.append(header)
        lines.append("|" + "---|" * (len(r.labels) + 1))
        for i, lab in enumerate(r.labels):
            row = " | ".join(str(v) for v in r.confusion[i])
            lines.append(f"| {lab} | {row} |")
    return "\n".join(lines)


def save_json(results: list[Metrics], path: str) -> None:
    with open(path, "w") as f:
        json.dump([r.to_dict() for r in results], f, indent=2)
