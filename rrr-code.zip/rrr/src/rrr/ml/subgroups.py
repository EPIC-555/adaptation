"""Break test performance down by pair difficulty.

Some Indian statutes are near-identical templates (the National Waterways Act
lists one clause per waterway; every clause reads "National Waterway N <river>:
<place> to <place>"). Two such clauses share almost all of their boilerplate and
differ only in proper nouns, so a pair of them is a much weaker test of legal
reasoning than two provisions that genuinely discuss the same subject.

This module separates the two and reports accuracy for each, so the headline
number can be checked rather than trusted. If the model scored well only on
template pairs, the gap between the two rows would show it.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

# Words that carry no subject matter: they appear in most statutory clauses.
_GENERIC = set("""
national waterway river lat lon village near bridge dam confluence border
from to at of the and or any such this that shall may under act section
""".split())

# Below this distinctive-word overlap the pair is treated as template-only.
_TEMPLATE_THRESHOLD = 0.15


def _distinctive(text: str) -> set[str]:
    return {w for w in re.findall(r"[a-z]{4,}", text.lower()) if w not in _GENERIC}


def jaccard(a: set, b: set) -> float:
    return len(a & b) / len(a | b) if a | b else 0.0


def classify_pairs(rows: list[dict]) -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = {"template_only": [], "substantive": []}
    for r in rows:
        overlap = jaccard(_distinctive(r["old_text"]), _distinctive(r["new_text"]))
        key = "template_only" if overlap < _TEMPLATE_THRESHOLD else "substantive"
        groups[key].append(r)
    return groups


def _accuracy(pairs: list[tuple[str, str]]) -> dict:
    if not pairs:
        return {"n": 0, "accuracy": None}
    correct = sum(a == b for a, b in pairs)
    return {"n": len(pairs), "accuracy": round(correct / len(pairs), 4),
            "correct": correct}


def analyse(pairs_path: str, predictions_path: str) -> dict:
    by_id = {r["pair_id"]: r for r in (json.loads(l) for l in open(pairs_path))}
    preds = json.load(open(predictions_path))

    rows = [by_id[p] for p in preds["test_pair_ids"]]
    groups = classify_pairs(rows)
    gold = dict(zip(preds["test_pair_ids"], preds["y_true"]))
    guess = dict(zip(preds["test_pair_ids"], preds["y_pred"]))

    out = {"template_threshold": _TEMPLATE_THRESHOLD, "groups": {}}
    for name, members in groups.items():
        pairs = [(gold[r["pair_id"]], guess[r["pair_id"]]) for r in members]
        stats = _accuracy(pairs)
        stats["label_counts"] = {}
        for r in members:
            stats["label_counts"][r["label"]] = stats["label_counts"].get(r["label"], 0) + 1
        out["groups"][name] = stats

    # Errors, with the document that produced them, for inspection.
    out["errors"] = [
        {"gold": gold[p], "predicted": guess[p], "doc": by_id[p]["new_filename"]}
        for p in preds["test_pair_ids"] if gold[p] != guess[p]
    ]
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="data/pairs.jsonl")
    ap.add_argument("--model-preds", default="artifacts/model_predictions.json")
    ap.add_argument("--out", default="reports/subgroups.json")
    args = ap.parse_args()

    result = analyse(args.pairs, args.model_preds)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(result, indent=2))

    print(f"template threshold: distinctive-word Jaccard < {result['template_threshold']}")
    for name, s in result["groups"].items():
        print(f"  {name:14s} n={s['n']:3d}  accuracy={s['accuracy']}  labels={s['label_counts']}")
    print(f"  total errors: {len(result['errors'])}")


if __name__ == "__main__":
    main()
