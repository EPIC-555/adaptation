"""Fine-tune a DeBERTa-v3 cross-encoder for the four-class relationship task.

The pair is encoded as a sentence pair: the earlier provision is the premise and
the proposed provision is the hypothesis. That matches how NLI cross-encoders
were pretrained, so the backbone starts from a useful representation.

Only the classification head and encoder are trained; the tokenizer and split
come from the locked dataset so the test set is never touched during training.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    EarlyStoppingCallback,
    Trainer,
    TrainerCallback,
    TrainingArguments,
)

from rrr.ml.metrics import LABELS

LABEL2ID = {lab: i for i, lab in enumerate(LABELS)}
ID2LABEL = {i: lab for lab, i in LABEL2ID.items()}


class PairDataset(Dataset):
    def __init__(self, rows: list[dict], tokenizer, max_len: int = 256):
        self.rows = rows
        self.tok = tokenizer
        self.max_len = max_len

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, i: int) -> dict:
        r = self.rows[i]
        enc = self.tok(r["old_text"], r["new_text"], truncation=True,
                       max_length=self.max_len, padding="max_length")
        return {
            "input_ids": torch.tensor(enc["input_ids"]),
            "attention_mask": torch.tensor(enc["attention_mask"]),
            "labels": torch.tensor(LABEL2ID[r["label"]]),
        }


def _metrics_fn(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    f1s = []
    for i in range(len(LABELS)):
        tp = int(((preds == i) & (labels == i)).sum())
        fp = int(((preds == i) & (labels != i)).sum())
        fn = int(((preds != i) & (labels == i)).sum())
        p = tp / (tp + fp) if tp + fp else 0.0
        r = tp / (tp + fn) if tp + fn else 0.0
        f1s.append(2 * p * r / (p + r) if p + r else 0.0)
    return {
        "accuracy": float((preds == labels).mean()) if len(labels) else 0.0,
        "macro_f1": float(np.mean(f1s)),
    }


def load_split(path: str) -> dict[str, list[dict]]:
    rows = [json.loads(l) for l in open(path)]
    return {s: [r for r in rows if r["split"] == s] for s in ("train", "val", "test")}


class SaveTokenizer(TrainerCallback):
    """Write the tokenizer into every checkpoint.

    `trainer.save_model` saves the model but not the tokenizer, and the saved
    config drops `_name_or_path`. Without this, loading a checkpoint cannot
    recover the tokenizer and silently picks up an unrelated one from the
    Hugging Face cache, which produces confident nonsense.
    """

    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def on_save(self, args, state, control, **kwargs):
        self.tokenizer.save_pretrained(args.output_dir)
        return control


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="data/pairs.jsonl")
    ap.add_argument("--model", default="cross-encoder/nli-deberta-v3-small")
    ap.add_argument("--out", default="artifacts/deberta-v3-small-rrr")
    ap.add_argument("--epochs", type=int, default=8)
    ap.add_argument("--lr", type=float, default=2e-5)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--max-len", type=int, default=256)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--predictions", default="artifacts/model_predictions.json")
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    split = load_split(args.pairs)
    print(f"train={len(split['train'])} val={len(split['val'])} test={len(split['test'])}")

    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForSequenceClassification.from_pretrained(
        args.model, num_labels=len(LABELS), id2label=ID2LABEL, label2id=LABEL2ID,
        ignore_mismatched_sizes=True,
    )
    # Keep the saved config self-describing so a checkpoint can recover its
    # tokenizer without being told the base model name.
    model.config._name_or_path = args.model

    # Total optimizer steps = epochs * ceil(train/batch); warm up over the first 10%.
    steps_per_epoch = max(1, len(split["train"]) // args.batch)
    targs = TrainingArguments(
        output_dir=args.out,
        num_train_epochs=args.epochs,
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch,
        per_device_eval_batch_size=args.batch,
        warmup_steps=max(1, int(0.1 * args.epochs * steps_per_epoch)),
        weight_decay=0.01,
        logging_steps=25,
        eval_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=2,
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        greater_is_better=True,
        report_to=[],
        use_cpu=True,
        seed=args.seed,
    )

    trainer = Trainer(
        model=model,
        args=targs,
        train_dataset=PairDataset(split["train"], tok, args.max_len),
        eval_dataset=PairDataset(split["val"], tok, args.max_len),
        compute_metrics=_metrics_fn,
        callbacks=[
            SaveTokenizer(tok),
            EarlyStoppingCallback(early_stopping_patience=3),
        ],
    )
    trainer.train()

    Path(args.out).mkdir(parents=True, exist_ok=True)
    trainer.save_model(args.out)
    tok.save_pretrained(args.out)

    # Test-set predictions, computed once, stored for the report and calibration.
    logits = trainer.predict(PairDataset(split["test"], tok, args.max_len))
    probs = torch.softmax(torch.tensor(logits.predictions), dim=-1).numpy()
    pred_ids = probs.argmax(axis=-1)

    val_logits = trainer.predict(PairDataset(split["val"], tok, args.max_len))
    val_probs = torch.softmax(torch.tensor(val_logits.predictions), dim=-1).numpy()

    Path(args.predictions).parent.mkdir(parents=True, exist_ok=True)
    with open(args.predictions, "w") as f:
        json.dump({
            "test_pair_ids": [r["pair_id"] for r in split["test"]],
            "y_true": [r["label"] for r in split["test"]],
            "y_pred": [ID2LABEL[int(i)] for i in pred_ids],
            "probs": probs.tolist(),
            "labels": list(LABELS),
            "val_y_true": [r["label"] for r in split["val"]],
            "val_probs": val_probs.tolist(),
            "val_y_pred": [ID2LABEL[int(i)] for i in val_probs.argmax(axis=-1)],
        }, f, indent=2)
    print("saved model to", args.out)
    print("saved predictions to", args.predictions)
    print("test metrics:", logits.metrics)


if __name__ == "__main__":
    main()
