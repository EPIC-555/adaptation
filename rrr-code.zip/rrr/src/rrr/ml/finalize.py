"""Evaluate a trained checkpoint and export it as the served model.

Training runs can be interrupted once validation stops improving. This script
takes the best checkpoint, copies it to the serving directory, and writes the
test- and validation-split predictions that `rrr.ml.report` and
`rrr.ml.calibrate` consume.

Nothing here selects on test performance: the checkpoint is chosen by
validation macro-F1, and the test set is only read to report a number.
"""
from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from rrr.ml.train import ID2LABEL, PairDataset, load_split


def _load_tokenizer(ckpt: Path, fallback_name: str):
    """Prefer the checkpoint's own tokenizer; otherwise the named base model.

    A checkpoint written before the SaveTokenizer callback has no tokenizer
    files, and `from_pretrained` will then quietly return a small unrelated
    tokenizer from the cache. That failure is silent and produces confident
    garbage, so it is checked rather than trusted.
    """
    if (ckpt / "tokenizer.json").exists() or (ckpt / "spiece.model").exists():
        return AutoTokenizer.from_pretrained(str(ckpt))
    print(f"checkpoint has no tokenizer files; using base tokenizer {fallback_name!r}")
    return AutoTokenizer.from_pretrained(fallback_name)


def check_tokenizer(tok, model) -> None:
    """Refuse to run if the tokenizer does not belong to the model.

    A tokenizer that does not match the embeddings yields confident nonsense, so
    this fails loudly rather than at query time. DeBERTa-v3 models legitimately
    pad the embedding matrix a little past the tokenizer's vocabulary (128000
    tokens against a 128100-row matrix), so the test is that the matrix can hold
    every token id and that real text tokenizes to real tokens.
    """
    emb = model.get_input_embeddings().weight.shape[0]
    if tok.vocab_size < 1000:
        raise ValueError(
            f"tokenizer in this directory has only {tok.vocab_size} tokens; "
            "it is not the tokenizer the model was trained with"
        )
    if emb < tok.vocab_size:
        raise ValueError(
            f"tokenizer vocab_size {tok.vocab_size} exceeds model embedding size {emb}"
        )
    probe = tok("the controller shall not discriminate", add_special_tokens=False)
    ids = probe["input_ids"]
    unk = tok.unk_token_id
    if ids and all(i == unk for i in ids):
        raise ValueError("tokenizer maps ordinary English to [UNK]; wrong tokenizer")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs", default="data/pairs.jsonl")
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--out-dir", default="artifacts/deberta-v3-small-rrr")
    ap.add_argument("--predictions", default="artifacts/model_predictions.json")
    ap.add_argument("--tokenizer", default="cross-encoder/nli-deberta-v3-small",
                    help="base model whose tokenizer the checkpoint was trained with")
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--max-len", type=int, default=256)
    args = ap.parse_args()

    ckpt = Path(args.checkpoint)
    state = json.loads((ckpt / "trainer_state.json").read_text())
    evals = [e for e in state["log_history"] if "eval_macro_f1" in e]
    if evals:
        best = max(evals, key=lambda e: e["eval_macro_f1"])
        print(f"checkpoint {ckpt.name}: validation macro-F1 "
              f"{best['eval_macro_f1']:.4f} at epoch {best['epoch']:.2f}")

    tok = _load_tokenizer(ckpt, args.tokenizer)
    model = AutoModelForSequenceClassification.from_pretrained(str(ckpt))
    model.eval()
    check_tokenizer(tok, model)

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if ckpt.resolve() != out_dir.resolve():
        for f in ckpt.iterdir():
            if f.is_file() and f.suffix in {".json", ".safetensors", ".bin", ".txt", ".model"}:
                shutil.copy2(f, out_dir / f.name)
    tok.save_pretrained(out_dir)
    print("exported model to", out_dir)

    split = load_split(args.pairs)
    result: dict = {"labels": list(ID2LABEL.values())}

    for name in ("test", "val"):
        rows = split[name]
        ds = PairDataset(rows, tok, args.max_len)
        preds, probs_all = [], []
        with torch.no_grad():
            for i in range(0, len(ds), args.batch):
                batch = [ds[j] for j in range(i, min(i + args.batch, len(ds)))]
                input_ids = torch.stack([b["input_ids"] for b in batch])
                attn = torch.stack([b["attention_mask"] for b in batch])
                logits = model(input_ids=input_ids, attention_mask=attn).logits
                probs = torch.softmax(logits, dim=-1)
                probs_all.extend(probs.tolist())
                preds.extend(ID2LABEL[int(p)] for p in probs.argmax(dim=-1))

        if name == "test":
            result["test_pair_ids"] = [r["pair_id"] for r in rows]
            result["y_true"] = [r["label"] for r in rows]
            result["y_pred"] = preds
            result["probs"] = probs_all
        else:
            result["val_y_true"] = [r["label"] for r in rows]
            result["val_y_pred"] = preds
            result["val_probs"] = probs_all
        print(f"{name}: {len(rows)} pairs evaluated")

    Path(args.predictions).parent.mkdir(parents=True, exist_ok=True)
    Path(args.predictions).write_text(json.dumps(result, indent=2))
    print("wrote", args.predictions)


if __name__ == "__main__":
    main()
