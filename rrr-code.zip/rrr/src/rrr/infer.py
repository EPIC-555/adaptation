"""Inference wrapper around the fine-tuned cross-encoder.

This is the single entry point used by the CLI demo and the HTTP API, so a
prediction shown in the UI is produced by exactly the same code path that was
evaluated in `reports/REPORT.md`.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

from rrr.ml.finalize import check_tokenizer

LABELS = ("conflicts", "removes_safeguard", "consistent", "unrelated")
RISK_LABELS = ("conflicts", "removes_safeguard")


@dataclass
class Prediction:
    label: str
    confidence: float
    probabilities: dict[str, float]
    needs_review: bool
    explanation: str

    def to_dict(self) -> dict:
        return asdict(self)


class PairClassifier:
    def __init__(self, model_dir: str = "artifacts/deberta-v3-small-rrr",
                 calibration_path: str = "artifacts/calibration.json",
                 max_len: int = 256):
        self.tok = AutoTokenizer.from_pretrained(model_dir)
        self.model = AutoModelForSequenceClassification.from_pretrained(model_dir)
        self.model.eval()
        self.max_len = max_len
        self.id2label = self.model.config.id2label
        check_tokenizer(self.tok, self.model)

        self.threshold = 0.5
        p = Path(calibration_path)
        if p.exists():
            self.threshold = json.loads(p.read_text()).get("review_threshold", 0.5)

    def classify(self, new_text: str, old_text: str) -> Prediction:
        enc = self.tok(old_text, new_text, truncation=True,
                       max_length=self.max_len, return_tensors="pt")
        with torch.no_grad():
            probs = self.model(**enc).logits.softmax(-1)[0]
        best = int(probs.argmax())
        label = self.id2label[best]
        confidence = float(probs[best])
        prob_map = {self.id2label[i]: float(probs[i]) for i in range(len(probs))}
        return Prediction(
            label=label,
            confidence=round(confidence, 4),
            probabilities={k: round(v, 4) for k, v in prob_map.items()},
            needs_review=confidence < self.threshold,
            explanation=_explain(label, confidence, prob_map, self.threshold),
        )


def _explain(label: str, confidence: float, probs: dict, threshold: float) -> str:
    if label == "removes_safeguard":
        base = ("The proposed provision drops a protection present in the earlier "
                "provision (for example a proviso, exemption or procedural right).")
    elif label == "conflicts":
        base = ("The proposed provision imposes an obligation that the earlier "
                "provision forbids, or negates an existing obligation; both cannot "
                "be satisfied at once.")
    elif label == "consistent":
        base = ("The proposed provision restates or refines the earlier provision "
                "without opposing it.")
    else:
        base = "The two provisions address different subject matter."
    tail = (f" Confidence {confidence:.2f} is below the review threshold "
            f"{threshold:.2f}, so this is routed to a human reviewer."
            if confidence < threshold else
            f" Confidence {confidence:.2f} meets the review threshold {threshold:.2f}.")
    return base + tail
