#!/usr/bin/env bash
# End-to-end pipeline. Every stage is reproducible from the raw PDFs.
#
#   ./run_pipeline.sh            full run (ingest -> dataset -> baselines -> train -> report)
#   ./run_pipeline.sh --fast     everything except training (for a quick smoke test)
#
# PYTHON must point at an interpreter with the dependencies in pyproject.toml.
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/src"
PYTHON="${PYTHON:-python}"
FAST="${1:-}"

echo "== 1/7 ingest PDFs -> clauses =="
"$PYTHON" -m rrr.ingest.build_corpus --corpus "${CORPUS:-/workspace/corpus}" --out data

echo "== 2/7 build labelled pairs =="
"$PYTHON" -m rrr.ml.dataset --clauses data/clauses.jsonl --documents data/documents.jsonl \
  --out data/pairs.jsonl --per-class 3000

echo "== 3/7 baselines on the locked test split =="
"$PYTHON" -m rrr.ml.baselines --pairs data/pairs.jsonl --out artifacts/baseline_predictions.json

if [ "$FAST" = "--fast" ]; then
  echo "== --fast: stopping before training =="
  exit 0
fi

echo "== 4/7 fine-tune DeBERTa-v3 cross-encoder (CPU, several hours) =="
"$PYTHON" -m rrr.ml.train --pairs data/pairs.jsonl \
  --model cross-encoder/nli-deberta-v3-small \
  --out artifacts/deberta-v3-small-rrr \
  --epochs 8 --lr 2e-5 --batch 8

echo "== 5/7 calibrate review threshold on validation =="
"$PYTHON" -m rrr.ml.calibrate --model-preds artifacts/model_predictions.json \
  --out artifacts/calibration.json --target 0.95

echo "== 6/7 comparison report =="
"$PYTHON" -m rrr.ml.report

echo "== 7/7 difficulty breakdown and retrieval evaluation =="
"$PYTHON" -m rrr.ml.subgroups --out reports/subgroups.json
"$PYTHON" -m rrr.retrieval.evaluate --out reports/retrieval_metrics.json

echo
echo "done. See reports/REPORT.md"
echo "serve the demo:  $PYTHON -m uvicorn rrr.api.service:app --host 0.0.0.0 --port 8000"
