# Evaluation

## Protocol

The test set was fixed before training and not read during development.

- **Split by document.** Each of the 202 documents belongs to exactly one split.
  A pair is kept only if both of its documents are in the same split. This is
  stricter than splitting by pair and prevents a clause from appearing in
  training and test at once.
- **Balanced.** 65 pairs per class in test (260 total), 45 per class in
  validation (180), 1,380 in training.
- **One scoring path.** `rrr.ml.metrics` computes every number below, from raw
  predictions, for all models.
- **Threshold on validation only.** The review threshold is chosen on the
  validation split and then reported on test.

## Four-class relationship classification

| Model | n | Accuracy | Macro-F1 |
|---|---|---|---|
| **DeBERTa-v3 cross-encoder (fine-tuned)** | 260 | **0.965** | **0.965** |
| TF-IDF + logistic regression | 260 | 0.631 | 0.560 |
| Zero-shot NLI (`nli-deberta-v3-small`) | 260 | 0.408 | 0.321 |
| Majority class | 260 | 0.250 | 0.100 |

Per-class results for the fine-tuned model:

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| conflicts | 1.000 | 0.969 | 0.984 | 65 |
| removes_safeguard | 0.956 | 1.000 | 0.977 | 65 |
| consistent | 0.954 | 0.954 | 0.954 | 65 |
| unrelated | 0.953 | 0.938 | 0.946 | 65 |

The fine-tuned model beats the best baseline by **+0.405 macro-F1**.

## Why zero-shot fails, and why that matters

The off-the-shelf NLI model has three labels: entailment, neutral, contradiction.
It has no way to express `removes_safeguard`. Its confusion matrix shows exactly
that — it predicts `removes_safeguard` **zero times**, sending all 65 of those
pairs to `consistent` or `unrelated`. Recall on the most safety-critical class is
0.000.

That is the whole argument for fine-tuning: the class the product exists to
detect is the one a general model cannot name. Fine-tuning raises that recall to
1.000.

The baseline is also weak on `consistent` (F1 0.000). Bag-of-words features
cannot tell "restates the same rule" from "contradicts the same rule", because
both share nearly all their words. A cross-encoder attends over the pair jointly
and can.

## Retrieval (the evidence step)

`reports/retrieval_metrics.json`, over 8,796 indexed clauses:

| Retriever | Self-retrieval R@1 | Self R@5 | Cross-provision R@1 | Cross R@5 | n |
|---|---|---|---|---|---|
| BM25 | 0.987 | 1.000 | 0.000 | 0.077 | 7,049 / 130 |
| Dense (`all-MiniLM-L6-v2`) | 0.992 | 1.000 | 0.000 | 0.069 | 7,049 / 130 |

**Self-retrieval** (query is the clause's own text) is near-perfect for both.
This is the case the product actually needs: given a proposed provision, find
the existing provision it restates or contradicts.

**Cross-provision** (find the *other* clause of a `consistent` pair) fails for
both. That number should not be read as a retriever failure, because the probe is
ill-posed. Inspecting the pairs shows why:

```
old: 14. National Waterway 14 Baitarni River: Dattapur village at Lat 20°51'45"N ...
new: 65. National Waterway 65 Mahananda River: Bridge near Gosaipur at Lat 25°26'41"N ...
```

These are different rivers. The pair was labelled `consistent` because the two
clauses share boilerplate, not because they concern the same subject. No
retriever can find a "partner" that has no lexical or semantic relation to the
query, and the label itself is weak. This is a dataset defect, discussed next.

## Dataset limitation this exposes

The `consistent` class is weaker than the other three. Measured over all 455
`consistent` pairs:

- 124 of 455 have almost no shared content words (distinctive-word Jaccard
  < 0.15) — they are matched on template, not subject
- 26 of 455 have more than 60% of their word *shape* in common — same template,
  different nouns

By contrast, 0 of 455 `conflicts` pairs are low-overlap (they are the same
clause, negated) and 454 of 455 `unrelated` pairs are low-overlap (that is the
definition). The rule that builds `consistent` — same Act, Jaccard >= 0.12 over
content words, no containment — admits template twins.

**Did this inflate the headline?** Measured directly
(`reports/subgroups.json`, `python -m rrr.ml.subgroups`), splitting the test set
by distinctive-word overlap:

| Subgroup | n | Accuracy |
|---|---|---|
| Template-only pairs | 129 | 0.961 |
| Substantive pairs | 131 | 0.969 |

The model scores slightly *higher* on the substantive pairs, so 0.965 is not an
artifact of template overlap. But it is still true that the model is being asked
to separate `consistent` template twins from `unrelated` pairs, which is close to
a coin flip in the ambiguous middle: 5 of the 9 test errors are
`consistent`/`unrelated` confusions.

## Human oversight

`ml/calibrate.py` picks the lowest threshold on validation that keeps risk-class
recall at or above the target:

- chosen threshold **0.30**, validation risk recall 0.967, coverage 1.000
- on test: risk recall **0.985**, coverage 1.000

Because the model is confident, essentially nothing falls below the threshold in
these splits. The mechanism matters when it does: a low-confidence prediction is
marked `needs_review` and the backend routes it to a person instead of showing
it as a finding.

## What these numbers do and do not support

Stated plainly, because a judge should be able to check the claim rather than
trust it.

**Do support:** on the constructed pairs described in `docs/LABELS.md`, the
fine-tuned model recovers the relationship at 0.965 macro-F1, far above both
baselines, and names `removes_safeguard` reliably where zero-shot cannot. The
score holds on the substantive subset (0.969) as well as the template subset
(0.961), so it is not an artifact of shared boilerplate.

**Do not support:**

1. **Performance on arbitrary real bill/Act pairs.** `conflicts` and
   `removes_safeguard` pairs are built by rule from real text (a proviso removed,
   a modal negated). The model has not been evaluated on pairs a real bill would
   produce against an unrelated Act.
2. **A claim that the model understands law.** It detects the textual form of a
   regression — a dropped proviso, an inverted obligation. A protection removed
   by restructuring with no surface cue would be missed.
3. **A strong `consistent` class.** Roughly a quarter of those pairs are template
   twins rather than provisions about the same subject, and the
   `consistent`/`unrelated` boundary holds 5 of the 9 test errors. Treat
   `consistent` as a negative class ("no regression detected"), not as a positive
   finding of sameness.
4. **Coverage of the amendment record.** The corpus contains 1,977 parsed
   amendment instructions, but only 66 name a principal Act that is itself in
   the corpus, so only those can form a before/after pair. The principal Acts
   are largely not in the uploaded set.

## Next steps, in order of expected value

1. Add the principal Acts to the corpus from India Code, so amendment
   instructions become usable before/after pairs and the training signal stops
   depending on constructed negatives.
2. Rebuild the `consistent` class from clause pairs that share subject matter
   once boilerplate (numbers, latitudes, river and place names) is stripped, so
   template twins no longer enter the class.
3. Build the hybrid retriever (BM25 + dense + reciprocal rank fusion) and measure
   it on a correctly posed cross-provision probe, once (2) supplies honest pairs.
4. Hand-label a small sample of naturally occurring bill/Act pairs and report
   performance there. This is the number that answers objection 1.
5. Repeat training over three seeds and report the spread, so 0.965 is presented
   as an estimate rather than a point.
