# How the labels were produced

A classifier needs `(pair) -> label`. Twelve years of statute PDFs give the
pairs but not the labels, and inventing them with a language model would make
every reported number meaningless. So labels come from deterministic rules over
real text. Each rule is checkable by reading the source.

## Corpus

202 PDFs from `github.com/EPIC-555/adaptation`, 3,320 pages, 8,796 extracted
clauses. 186 PDFs are born-digital and extract cleanly; 16 are image-only scans
and are excluded from the dataset and reported as `needs_ocr` in
`data/documents.jsonl`.

## The four rules

### `removes_safeguard`
Source: real clauses containing a proviso (`Provided that ...`).

A proviso is the standard Indian drafting device for carving out an exception or
adding a procedural protection. The pair is:

```
old_text = the clause with its proviso
new_text = the same clause with the proviso deleted
```

The label is true by construction: the protection that existed in `old_text` is
absent from `new_text`. Both sides are real statutory text; only the removal is
constructed.

### `conflicts`
Source: real clauses stating an obligation, with no existing negation.

The pair is:

```
old_text = the real clause
new_text = the same clause with its modal negated
           (shall -> shall not, may -> shall not, is entitled to -> is not entitled to)
```

The two provisions cannot both be satisfied, so the relationship is
contradiction. This is the same transformation a bill would apply when it
inverts an obligation.

### `consistent`
Source: two real clauses from the same Act.

Both must share subject-matter terms (Jaccard similarity over content words
>= 0.12) and neither may contain the other. Same Act plus overlapping subject
plus no opposing modality means the provisions do not conflict.

Known weakness: overlap of 0.12 also admits *template twins* — two clauses that
share boilerplate but not subject matter. The National Waterways Act, for
example, lists one near-identical clause per river:

```
14. National Waterway 14 Baitarni River: Dattapur village at Lat 20°51'45"N ...
65. National Waterway 65 Mahananda River: Bridge near Gosaipur at Lat 25°26'41"N ...
```

Those two are different rivers and their pairing as `consistent` is weak. 124 of
the 455 `consistent` pairs are of this kind. `docs/EVALUATION.md` measures the
effect on the reported score and shows it does not inflate it, but the class is
the weakest of the four and is best read as "no regression detected".

### `unrelated`
Source: two real clauses from different Acts.

Content-word Jaccard similarity must be <= 0.05, so there is no shared subject
matter to establish a relationship.

## Why these rules, and what they cost

They are mechanical, so the dataset can be rebuilt and audited. The trade-off is
that `conflicts` and `removes_safeguard` pairs are adversarial constructions
rather than naturally occurring pairs of two different Acts.

Practical consequences, stated plainly:

- The task is harder than it looks. A model cannot solve `conflicts` by noticing
  the two texts are different; it has to notice the negation.
- Performance on these constructed pairs is **not** a claim about performance on
  arbitrary real bill/Act pairs. `docs/EVALUATION.md` says what the numbers do
  and do not support.
- A model that learns only surface cues will be caught by the `consistent` class,
  where the two texts are also different but the relationship is not a conflict.

## Structural labels from amendment Acts (not used for training)

Amendment Acts state their own effect: `shall be omitted`,
`shall be substituted`, `shall be inserted`, `shall be renumbered`. The parser in
`src/rrr/ingest/amendments.py` extracts 1,977 such instructions from the corpus,
with the target Act resolved for 1,639 of them.

These are **not** used as training labels, for a reason worth stating: only 66 of
those instructions name a principal Act that is itself present in the corpus. For
the rest there is no "before" text to pair against, so a pair cannot be formed.
`docs/EVALUATION.md` records this and the path to closing the gap.
