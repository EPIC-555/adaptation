# Architecture

```
                    PDFs (202 Indian statutes)
                              |
                    ingest/pdf.py         text extraction + scan detection
                              |
                    ingest/clauses.py     section-aware splitting -> 8,796 clauses
                              |
              +---------------+----------------+
              |                                |
      ml/dataset.py                  ingest/amendments.py
      labelled pairs                 structural instructions (analysis only)
              |
      +-------+--------+-------------------+
      |                |                   |
  ml/baselines.py   ml/train.py       ml/calibrate.py
  TF-IDF, NLI       DeBERTa-v3        review threshold
      |             cross-encoder           |
      +--------+--------+-------------------+
               |
        ml/metrics.py + ml/report.py  ->  reports/REPORT.md
```

## Serving path

```
  frontend / existing backend
            |
      api/service.py            FastAPI
        /classify               one pair
        /analyze                retrieve then classify
        /retrieve               evidence only
        /metrics                the evaluation report
        /demo                   demonstration page
            |
      infer.py                  PairClassifier (single inference path)
      retrieval/index.py        BM25 over 8,796 clauses
```

`infer.py` is the only place a prediction is produced. The CLI demo and the HTTP
API both call it, so a number shown to a judge comes from the same code that was
evaluated.

## Why a cross-encoder

The task is a judgement about a *pair* of texts, not about either text alone. A
cross-encoder attends over both sequences jointly, which is what the relationship
between them requires. DeBERTa-v3 pretrained on NLI is a good starting point
because entailment, contradiction and neutral are close relatives of
`consistent`, `conflicts` and `unrelated`; only `removes_safeguard` has no
counterpart in NLI, which is why the classifier head is retrained to four labels.

`ignore_mismatched_sizes=True` keeps the encoder weights and reinitialises the
3-way NLI head as a 4-way head. The training log records this as
`classifier.weight MISMATCH ... ckpt: torch.Size([3, 768]) vs model:torch.Size([4, 768])`.

## Retrieval

Two retrievers behind one interface (`search(text, k) -> hits`):

- **BM25** (`retrieval/index.py`) — no dependencies, strong on exact legal
  terminology. Measured Recall@1 of 0.987 when the query is the clause's own
  text.
- **Dense** (`retrieval/dense.py`) — `all-MiniLM-L6-v2` embeddings, for cases
  where the same rule is worded differently.

Measured numbers for both, including where each fails, are in
`reports/retrieval_metrics.json` and discussed in `docs/EVALUATION.md`.

## Human oversight

`ml/calibrate.py` picks a confidence threshold on the **validation** split to
hold recall on the risk classes (`conflicts`, `removes_safeguard`) above a
target. `infer.py` marks anything below that threshold
`needs_review=True`, and the backend adapter maps that to
`insufficient_evidence=True`, which the existing pipeline already routes to a
reviewer. The threshold, its validation coverage and its test-split behaviour
are written to `artifacts/calibration.json`.

## Connecting to the existing backend

`integration/backend_adapter.py` implements the two interfaces that backend
already declares — `MLAdapter` and `RetrievalAdapter` — so no endpoint, job or
model changes. Set `RRR_HOME` if this repository is not at `/workspace/rrr`.
