# Model evaluation

All figures below were produced by `python -m rrr.ml.report` on the held-out test split. No estimated or placeholder values.

## Summary

| Model | n | Accuracy | Macro-F1 |
|---|---|---|---|
| DeBERTa-v3 cross-encoder (fine-tuned) | 260 | 0.965 | 0.965 |
| TF-IDF + logistic regression | 260 | 0.631 | 0.560 |
| Zero-shot NLI (no fine-tuning) | 260 | 0.408 | 0.321 |
| Majority class | 260 | 0.250 | 0.100 |

## DeBERTa-v3 cross-encoder (fine-tuned)

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| conflicts | 1.000 | 0.969 | 0.984 | 65 |
| removes_safeguard | 0.956 | 1.000 | 0.977 | 65 |
| consistent | 0.954 | 0.954 | 0.954 | 65 |
| unrelated | 0.953 | 0.938 | 0.946 | 65 |

Accuracy 0.965 · Macro-F1 0.965 · n=260

Confusion matrix (rows = gold, cols = predicted):

| gold \ pred | conflicts | removes_safeguard | consistent | unrelated |
|---|---|---|---|---|
| conflicts | 63 | 2 | 0 | 0 |
| removes_safeguard | 0 | 65 | 0 | 0 |
| consistent | 0 | 0 | 62 | 3 |
| unrelated | 0 | 1 | 3 | 61 |

## TF-IDF + logistic regression

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| conflicts | 0.434 | 0.815 | 0.567 | 65 |
| removes_safeguard | 0.831 | 0.908 | 0.868 | 65 |
| consistent | 0.000 | 0.000 | 0.000 | 65 |
| unrelated | 0.812 | 0.800 | 0.806 | 65 |

Accuracy 0.631 · Macro-F1 0.560 · n=260

Confusion matrix (rows = gold, cols = predicted):

| gold \ pred | conflicts | removes_safeguard | consistent | unrelated |
|---|---|---|---|---|
| conflicts | 53 | 6 | 0 | 6 |
| removes_safeguard | 2 | 59 | 0 | 4 |
| consistent | 63 | 0 | 0 | 2 |
| unrelated | 4 | 6 | 3 | 52 |

## Zero-shot NLI (no fine-tuning)

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| conflicts | 0.417 | 0.969 | 0.583 | 65 |
| removes_safeguard | 0.000 | 0.000 | 0.000 | 65 |
| consistent | 0.000 | 0.000 | 0.000 | 65 |
| unrelated | 0.741 | 0.662 | 0.699 | 65 |

Accuracy 0.408 · Macro-F1 0.321 · n=260

Confusion matrix (rows = gold, cols = predicted):

| gold \ pred | conflicts | removes_safeguard | consistent | unrelated |
|---|---|---|---|---|
| conflicts | 63 | 0 | 1 | 1 |
| removes_safeguard | 6 | 0 | 46 | 13 |
| consistent | 64 | 0 | 0 | 1 |
| unrelated | 18 | 0 | 4 | 43 |

## Majority class

| Class | Precision | Recall | F1 | Support |
|---|---|---|---|---|
| conflicts | 0.250 | 1.000 | 0.400 | 65 |
| removes_safeguard | 0.000 | 0.000 | 0.000 | 65 |
| consistent | 0.000 | 0.000 | 0.000 | 65 |
| unrelated | 0.000 | 0.000 | 0.000 | 65 |

Accuracy 0.250 · Macro-F1 0.100 · n=260

Confusion matrix (rows = gold, cols = predicted):

| gold \ pred | conflicts | removes_safeguard | consistent | unrelated |
|---|---|---|---|---|
| conflicts | 65 | 0 | 0 | 0 |
| removes_safeguard | 65 | 0 | 0 | 0 |
| consistent | 65 | 0 | 0 | 0 |
| unrelated | 65 | 0 | 0 | 0 |

## Headline

Highest macro-F1 on the held-out test split: **DeBERTa-v3 cross-encoder (fine-tuned)** at macro-F1 0.965 and accuracy 0.965 over 260 pairs.
